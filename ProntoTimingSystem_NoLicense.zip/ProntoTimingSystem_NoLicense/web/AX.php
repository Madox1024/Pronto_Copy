<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>LSFest 3 S Challenge </b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class=''>  RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for AX [48 Cars] (03:03:27 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>330</b></TD>
<TD colspan=2><b>Josh Cummings</b></TD>
<TD colspan=4><b>2017 Chevrolet Corvette</b></TD>
<TD>35.217</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.900</TD>
<TD class='course1'><b>17.668</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.938</TD>
<TD class='course2'><b>17.549</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 2</b></TD>
<TD><b>336</b></TD>
<TD colspan=2><b>KAREN LEISINGER</b></TD>
<TD colspan=4><b>1970 Chevrolet Camaro</b></TD>
<TD>35.714</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.187</TD>
<TD class='course1'>18.794</TD>
<TD class='course1'>18.612</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.096</TD>
<TD class='course2'>17.959</TD>
<TD class='course2'>18.427</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.066</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.648</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 3</b></TD>
<TD><b>300</b></TD>
<TD colspan=2><b>Michael Arlie</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>35.736</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.983</TD>
<TD class='course1'>18.102</TD>
<TD class='course1'>18.230</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.486</TD>
<TD class='course2'>18.449</TD>
<TD class='course2'>18.544</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.668</b></TD>
<TD class='course1'>17.998</TD>
<TD class='course1'>18.046</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.068</b></TD>
<TD class='course2'>18.791</TD>
<TD class='course2'>18.377</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.323</TD>
<TD class='course1'>18.446</TD>
<TD class='course1'>18.045</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.606</TD>
<TD class='course2'>18.618</TD>
<TD class='course2'>18.828</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.745</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.528</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 4</b></TD>
<TD><b>334</b></TD>
<TD colspan=2><b>GLENN BARRETTO</b></TD>
<TD colspan=4><b>2017 Chevrolet Corvette</b></TD>
<TD>35.875</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.361</TD>
<TD class='course1'>18.875</TD>
<TD class='course1'>19.013</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.553</TD>
<TD class='course2'>18.713</TD>
<TD class='course2'>18.446</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.590</TD>
<TD class='course1'>18.391</TD>
<TD class='course1'>18.941</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.426</TD>
<TD class='course2'>18.735</TD>
<TD class='course2'>18.386</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.888</TD>
<TD class='course1'>18.368</TD>
<TD class='course1'><b>18.058</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.283</TD>
<TD class='course2'>18.312</TD>
<TD class='course2'>18.202</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.400</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.817</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 5</b></TD>
<TD><b>309</b></TD>
<TD colspan=2><b>Raymond Sanchez</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>36.116</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.934</TD>
<TD class='course1'>19.454</TD>
<TD class='course1'>18.282</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.003</TD>
<TD class='course2'>20.315</TD>
<TD class='course2'>18.620</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.821</TD>
<TD class='course1'>18.766</TD>
<TD class='course1'>18.955</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.700</TD>
<TD class='course2'>18.439</TD>
<TD class='course2'>18.853</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.891</TD>
<TD class='course1'>19.084</TD>
<TD class='course1'>18.882</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.038</TD>
<TD class='course2'>18.922</TD>
<TD class='course2'><b>17.972</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.334</TD>
<TD class='course1'><b>18.144</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.369</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 6</b></TD>
<TD><b>308</b></TD>
<TD colspan=2><b>Donald Robertson</b></TD>
<TD colspan=4><b>2017 Chevrolet Camaro</b></TD>
<TD>36.667</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.777</TD>
<TD class='course1'>19.235</TD>
<TD class='course1'>19.083</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.663</TD>
<TD class='course2'>19.504</TD>
<TD class='course2'>18.933</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.474</TD>
<TD class='course1'>18.433</TD>
<TD class='course1'>18.872</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.216</TD>
<TD class='course2'>18.609</TD>
<TD class='course2'>19.309</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.613</TD>
<TD class='course1'>18.985</TD>
<TD class='course1'>18.232</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.736</TD>
<TD class='course2'><b>18.466</b></TD>
<TD class='course2'>18.637</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.201</b></TD>
<TD class='course1'>18.607</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.566</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 7</b></TD>
<TD><b>305</b></TD>
<TD colspan=2><b>Gary Kinney</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>37.539</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.071</TD>
<TD class='course1'>19.431</TD>
<TD class='course1'><b>19.006</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.372</TD>
<TD class='course2'>19.298</TD>
<TD class='course2'>18.613</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.371</TD>
<TD class='course1'>19.059</TD>
<TD class='course1'>20.817</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.068</TD>
<TD class='course2'>18.537</TD>
<TD class='course2'>18.732</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.109</TD>
<TD class='course1'>19.084</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.533</b></TD>
<TD class='course2'>18.620</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 8</b></TD>
<TD><b>322</b></TD>
<TD colspan=2><b>Joseph Escobar</b></TD>
<TD colspan=4><b>1999 Chevrolet Corvette</b></TD>
<TD>37.621</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.467</TD>
<TD class='course1'>19.962</TD>
<TD class='course1'>19.142</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.847</TD>
<TD class='course2'>20.251</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.705</TD>
<TD class='course1'><b>18.990</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.155</TD>
<TD class='course2'><b>18.631</b></TD>
<TD class='course2'>18.777</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.009</TD>
<TD class='course1'>19.466</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>21.938</TD>
<TD class='course2'>19.058</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 9</b></TD>
<TD><b>329</b></TD>
<TD colspan=2><b>Shezmil Singh</b></TD>
<TD colspan=4><b>2014 Chevrolet Camaro</b></TD>
<TD>38.293</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.344</TD>
<TD class='course1'>20.019</TD>
<TD class='course1'>20.715</TD>
<TD>&nbsp;</TD>
<TD class='course2'>21.045</TD>
<TD class='course2'>20.171</TD>
<TD class='course2'><b>19.202</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.711</TD>
<TD class='course1'>19.768</TD>
<TD class='course1'>20.619</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.533</TD>
<TD class='course2'>20.100</TD>
<TD class='course2'>19.733</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>19.091</b></TD>
<TD class='course1'>19.387</TD>
<TD class='course1'>20.511</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.537</TD>
<TD class='course2'>20.326</TD>
<TD class='course2'>20.479</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.890</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>10</b></TD>
<TD><b>333</b></TD>
<TD colspan=2><b>Sterling Dahl</b></TD>
<TD colspan=4><b>2011 Chevrolet Camaro</b></TD>
<TD>39.337</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.520</TD>
<TD class='course1'><b>19.374</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.089</TD>
<TD class='course2'><b>19.963</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>11</b></TD>
<TD><b>311</b></TD>
<TD colspan=2><b>SAMMY VALAFAR</b></TD>
<TD colspan=4><b>2007 Cadillac CTS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>27.260</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>12</b></TD>
<TD><b>323</b></TD>
<TD colspan=2><b>Goosse Mejia</b></TD>
<TD colspan=4><b>2019 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>13</b></TD>
<TD><b>316</b></TD>
<TD colspan=2><b>Brandon Kishbaugh</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>14</b></TD>
<TD><b>338</b></TD>
<TD colspan=2><b>Grady Joseph</b></TD>
<TD colspan=4><b>2016 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>15</b></TD>
<TD><b>315</b></TD>
<TD colspan=2><b>Marcus Johnson</b></TD>
<TD colspan=4><b>2008 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>16</b></TD>
<TD><b>314</b></TD>
<TD colspan=2><b>Brian Graspointner</b></TD>
<TD colspan=4><b>1974 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>17</b></TD>
<TD><b>304</b></TD>
<TD colspan=2><b>Megan Freiberg</b></TD>
<TD colspan=4><b>2006 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>18</b></TD>
<TD><b>317</b></TD>
<TD colspan=2><b>Chris Payton</b></TD>
<TD colspan=4><b>2006 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>19</b></TD>
<TD><b>137</b></TD>
<TD colspan=2><b>Ean East</b></TD>
<TD colspan=4><b>2011 Chevy Camaro SS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>20</b></TD>
<TD><b>303</b></TD>
<TD colspan=2><b>ervin crump</b></TD>
<TD colspan=4><b>2004 Pontiac GTO</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>21</b></TD>
<TD><b>302</b></TD>
<TD colspan=2><b>Juan Contreras</b></TD>
<TD colspan=4><b>1991 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>22</b></TD>
<TD><b>301</b></TD>
<TD colspan=2><b>Thomas Carstens</b></TD>
<TD colspan=4><b>2008 Pontiac G8</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>23</b></TD>
<TD><b>335</b></TD>
<TD colspan=2><b>Juan BARRERA</b></TD>
<TD colspan=4><b>2013 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>24</b></TD>
<TD><b>327</b></TD>
<TD colspan=2><b>Bronson Bair</b></TD>
<TD colspan=4><b>1978 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>25</b></TD>
<TD><b>326</b></TD>
<TD colspan=2><b>Fernando Avelar</b></TD>
<TD colspan=4><b>2016 Chevrolet SS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>26</b></TD>
<TD><b>313</b></TD>
<TD colspan=2><b>Kyle Gardner</b></TD>
<TD colspan=4><b>1984 Chevrolet C10</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>27</b></TD>
<TD><b>343</b></TD>
<TD colspan=2><b>Alex Taylor</b></TD>
<TD colspan=4><b>x x x</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>28</b></TD>
<TD><b>925</b></TD>
<TD colspan=2><b>Allen Marcus</b></TD>
<TD colspan=4><b>1964 Chevy Impala</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>29</b></TD>
<TD><b>341</b></TD>
<TD colspan=2><b>Juan Trejo</b></TD>
<TD colspan=4><b>2007 Chevy Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>30</b></TD>
<TD><b>345</b></TD>
<TD colspan=2><b>Claudia Moreno</b></TD>
<TD colspan=4><b>2005 chevy RST</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>31</b></TD>
<TD><b>344</b></TD>
<TD colspan=2><b>Charles Dumez</b></TD>
<TD colspan=4><b>2000 Pontiac Fireebird</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>32</b></TD>
<TD><b>332</b></TD>
<TD colspan=2><b>JEREMY WOLIN</b></TD>
<TD colspan=4><b>1998 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>33</b></TD>
<TD><b>312</b></TD>
<TD colspan=2><b>James White</b></TD>
<TD colspan=4><b>1968 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>34</b></TD>
<TD><b>325</b></TD>
<TD colspan=2><b>Kelly Wheeler</b></TD>
<TD colspan=4><b>1964 Chevrolet Chevy II</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>35</b></TD>
<TD><b>321</b></TD>
<TD colspan=2><b>Solon Towner</b></TD>
<TD colspan=4><b>1971 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>36</b></TD>
<TD><b>306</b></TD>
<TD colspan=2><b>Robert Milne</b></TD>
<TD colspan=4><b>1997 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>37</b></TD>
<TD><b>320</b></TD>
<TD colspan=2><b>Kurt Thorson</b></TD>
<TD colspan=4><b>2009 Pontiac G8</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>38</b></TD>
<TD><b>307</b></TD>
<TD colspan=2><b>Raul Meza</b></TD>
<TD colspan=4><b>2002 Pontiac Firebird</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>39</b></TD>
<TD><b>337</b></TD>
<TD colspan=2><b>Ray Strods</b></TD>
<TD colspan=4><b>1999 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>40</b></TD>
<TD><b>310</b></TD>
<TD colspan=2><b>Brian T Stanley</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>41</b></TD>
<TD><b>319</b></TD>
<TD colspan=2><b>Taylor Slade</b></TD>
<TD colspan=4><b>1989 Volvo 245</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>42</b></TD>
<TD><b>318</b></TD>
<TD colspan=2><b>Dylan Simsay</b></TD>
<TD colspan=4><b>1991 Nissan 240SX</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>43</b></TD>
<TD><b>339</b></TD>
<TD colspan=2><b>Tyler Shoaf</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>44</b></TD>
<TD><b>324</b></TD>
<TD colspan=2><b>Kyle Sepulveda</b></TD>
<TD colspan=4><b>1966 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>45</b></TD>
<TD><b>340</b></TD>
<TD colspan=2><b>Ignacio Sanchez</b></TD>
<TD colspan=4><b>2002 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>46</b></TD>
<TD><b>346</b></TD>
<TD colspan=2><b>Lance Martin</b></TD>
<TD colspan=4><b>1964 Chevy camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>47</b></TD>
<TD><b>328</b></TD>
<TD colspan=2><b>Juan Munoz</b></TD>
<TD colspan=4><b>2014 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>48</b></TD>
<TD><b>331</b></TD>
<TD colspan=2><b>michael toscano</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
</Table>

