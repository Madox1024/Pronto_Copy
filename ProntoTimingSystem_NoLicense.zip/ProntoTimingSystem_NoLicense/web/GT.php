<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>FM3 Drive AutoX Traders World 2021</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class='UNOFFICIAL'> UNOFFICIAL RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for GT [24 Cars] (03:32:43 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD colspan=2><b>Car</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>Time</b></font></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 1</TD>
<TD>980</TD>
<TD colspan=2>James Vital</TD>
<TD colspan=2>1998 Nissan 240sx</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.012</TD>
<TD>49.987</TD>
<TD>48.046</TD>
<TD>47.979</TD>
<TD>48.561</TD>
<TD>47.590</TD>
<TD>&nbsp;</TD>
<TD><b>47.309</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>48.114</TD>
<TD>49.008(1)</TD>
<TD>48.614(1)</TD>
<TD><b>47.309</b></TD>
<TD>49.372(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 2</TD>
<TD>96</TD>
<TD colspan=2>Nathan Popp</TD>
<TD colspan=2>1995 Chevrolet Camaro Z28</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.406</TD>
<TD>49.069</TD>
<TD><s>49.696</s></TD>
<TD>47.936</TD>
<TD>50.339(1)</TD>
<TD>52.324(2)</TD>
<TD>&nbsp;</TD>
<TD><b>47.540</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>48.084</TD>
<TD>49.484(1)</TD>
<TD>51.123(2)</TD>
<TD>49.616(1)</TD>
<TD>53.059</TD>
<TD><b>47.540</b></TD>
<TD>&nbsp;</TD>
<TD>(0.231)</TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 3</TD>
<TD>55</TD>
<TD colspan=2>James Bishir</TD>
<TD colspan=2>2017 Chevrolet Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.290</TD>
<TD>53.882(2)</TD>
<TD>51.792(1)</TD>
<TD>51.716(1)</TD>
<TD>48.631</TD>
<TD>51.071(1)</TD>
<TD>&nbsp;</TD>
<TD><b>48.277</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.909(1)</TD>
<TD>51.098(1)</TD>
<TD>48.833</TD>
<TD>48.745</TD>
<TD><b>48.277</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.737)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 4</TD>
<TD>350</TD>
<TD colspan=2>James Thomas</TD>
<TD colspan=2>2016 Ford Mustang GT350</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.171</TD>
<TD><s>52.889</s></TD>
<TD>50.001</TD>
<TD>51.006(1)</TD>
<TD>48.786</TD>
<TD>52.964(2)</TD>
<TD>&nbsp;</TD>
<TD><b>48.469</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><b>48.469</b></TD>
<TD>49.639(1)</TD>
<TD>51.933(2)</TD>
<TD>48.638</TD>
<TD>49.793(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.192)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 5</TD>
<TD>13</TD>
<TD colspan=2>Brian Dixon</TD>
<TD colspan=2>2000 Pontiac/SLP Firehawk</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.748(1)</TD>
<TD>58.700</TD>
<TD>51.987(1)</TD>
<TD>50.532</TD>
<TD>50.135</TD>
<TD>50.527</TD>
<TD>&nbsp;</TD>
<TD><b>48.980</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.106</TD>
<TD>49.153</TD>
<TD><b>48.980</b></TD>
<TD>49.766</TD>
<TD>50.154</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.511)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 6</TD>
<TD>17</TD>
<TD colspan=2>Anthony Grace</TD>
<TD colspan=2>2017 Chevrolet Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.568(1)</TD>
<TD>55.562(3)</TD>
<TD>52.737(2)</TD>
<TD>51.268(1)</TD>
<TD>51.801(1)</TD>
<TD>50.406</TD>
<TD>&nbsp;</TD>
<TD><b>49.072</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><b>49.072</b></TD>
<TD>50.695(1)</TD>
<TD>49.180</TD>
<TD>49.476</TD>
<TD>57.459(4)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.092)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 7</TD>
<TD>991</TD>
<TD colspan=2>Ron Schoch</TD>
<TD colspan=2>2016 Mustang Ford</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.085(1)</TD>
<TD><s>49.095</s></TD>
<TD>53.356</TD>
<TD><s>53.323</s></TD>
<TD>51.989(1)</TD>
<TD><s>51.949</s></TD>
<TD>&nbsp;</TD>
<TD><b>49.116</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.976(3)</TD>
<TD>50.205</TD>
<TD>55.392(3)</TD>
<TD><b>49.116</b></TD>
<TD>51.500(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.044)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 8</TD>
<TD>210</TD>
<TD colspan=2>Brad Davidson</TD>
<TD colspan=2>2019 Ford Mustang</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>57.499</TD>
<TD>53.946</TD>
<TD>52.571</TD>
<TD>51.199</TD>
<TD>50.611</TD>
<TD>51.334</TD>
<TD>&nbsp;</TD>
<TD><b>49.982</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.513</TD>
<TD>50.666</TD>
<TD><b>49.982</b></TD>
<TD>52.879(1)</TD>
<TD>50.296</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.866)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 9</TD>
<TD>44</TD>
<TD colspan=2>Payton Kettlewell</TD>
<TD colspan=2>2004 Infiniti G35</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><b>50.636</b>(2)</TD>
<TD>61.141(2)</TD>
<TD>60.824(2)</TD>
<TD>58.428(1)</TD>
<TD>56.243</TD>
<TD>56.323</TD>
<TD>&nbsp;</TD>
<TD><b>50.636</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.377</TD>
<TD>57.560(1)</TD>
<TD>57.730(1)</TD>
<TD><s>55.421</s></TD>
<TD>58.832(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.654)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>10</TD>
<TD>888</TD>
<TD colspan=2>Nick Grotte</TD>
<TD colspan=2>2017 Chevy Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.479</TD>
<TD>55.155(1)</TD>
<TD>73.555(8)</TD>
<TD>53.450(1)</TD>
<TD><b>50.657</b></TD>
<TD><s>40.537</s></TD>
<TD>&nbsp;</TD>
<TD><b>50.657</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.437</TD>
<TD>51.914</TD>
<TD><s>52.458</s></TD>
<TD>51.718</TD>
<TD>53.843(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.021)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>11</TD>
<TD>444</TD>
<TD colspan=2>Cameron Joseph</TD>
<TD colspan=2>2001 Chevrolet Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>56.605(1)</TD>
<TD>53.416</TD>
<TD>51.808</TD>
<TD><s>72.110</s></TD>
<TD>53.427(1)</TD>
<TD>51.640</TD>
<TD>&nbsp;</TD>
<TD><b>50.719</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.142</TD>
<TD>50.964</TD>
<TD>51.167</TD>
<TD><b>50.719</b></TD>
<TD>52.392(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.062)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>12</TD>
<TD>28</TD>
<TD colspan=2>Gene Pooler</TD>
<TD colspan=2>2000 Ford Mustang Saleen</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>58.364(2)</TD>
<TD><s>55.576</s></TD>
<TD>52.535</TD>
<TD>51.918</TD>
<TD>53.586(1)</TD>
<TD>52.906</TD>
<TD>&nbsp;</TD>
<TD><b>50.945</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.128(1)</TD>
<TD>51.442</TD>
<TD>53.306(1)</TD>
<TD><b>50.945</b></TD>
<TD>51.067</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.226)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>13</TD>
<TD>77</TD>
<TD colspan=2>Terence Prell</TD>
<TD colspan=2>1999 Pontiac Firehawk</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>56.452</TD>
<TD>54.048</TD>
<TD>52.324</TD>
<TD>51.431</TD>
<TD>51.416</TD>
<TD>52.305</TD>
<TD>&nbsp;</TD>
<TD><b>51.226</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.506</TD>
<TD>51.285</TD>
<TD>54.075(1)</TD>
<TD>54.764(2)</TD>
<TD><b>51.226</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.281)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>14</TD>
<TD>312</TD>
<TD colspan=2>Cory Leonard</TD>
<TD colspan=2>2019 Ford Mustang</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>59.058</TD>
<TD>55.559</TD>
<TD>56.004(1)</TD>
<TD>54.218</TD>
<TD>54.165</TD>
<TD>54.172</TD>
<TD>&nbsp;</TD>
<TD><b>51.435</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.165</TD>
<TD>54.402(1)</TD>
<TD>53.582(1)</TD>
<TD><b>51.435</b></TD>
<TD>53.710</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.209)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>15</TD>
<TD>23</TD>
<TD colspan=2>AJ knollman</TD>
<TD colspan=2>1998 Chevrolet Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.525</TD>
<TD>54.521</TD>
<TD>53.566</TD>
<TD>54.194(1)</TD>
<TD>53.369</TD>
<TD>52.322</TD>
<TD>&nbsp;</TD>
<TD><b>51.520</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.826</TD>
<TD><b>51.520</b></TD>
<TD>54.876(1)</TD>
<TD>52.280</TD>
<TD>51.828</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.085)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>16</TD>
<TD>83</TD>
<TD colspan=2>Tami Staup</TD>
<TD colspan=2>2002 Pontiac Firebird Formula</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.423</TD>
<TD>53.652</TD>
<TD>52.588</TD>
<TD><s>61.641</s></TD>
<TD>52.020</TD>
<TD>52.347</TD>
<TD>&nbsp;</TD>
<TD><b>51.753</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.047(1)</TD>
<TD>52.158</TD>
<TD><b>51.753</b></TD>
<TD>52.151</TD>
<TD>51.971</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.233)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>17</TD>
<TD>717</TD>
<TD colspan=2>Ian Rock</TD>
<TD colspan=2>2021 Chevrolet Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>59.918</TD>
<TD>59.093(1)</TD>
<TD>55.859</TD>
<TD><s>41.491</s></TD>
<TD>56.648(1)</TD>
<TD>55.354</TD>
<TD>&nbsp;</TD>
<TD><b>51.782</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.684</TD>
<TD>56.324(1)</TD>
<TD>53.947</TD>
<TD>53.681</TD>
<TD><b>51.782</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.029)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>18</TD>
<TD>777</TD>
<TD colspan=2>BRIAN ROCK</TD>
<TD colspan=2>2021 Chevrolet Camaro SS 1LE</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><s>63.308</s></TD>
<TD>58.190(1)</TD>
<TD>56.819(1)</TD>
<TD>53.277</TD>
<TD>53.150</TD>
<TD>54.092</TD>
<TD>&nbsp;</TD>
<TD><b>52.688</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><s>60.365</s></TD>
<TD>52.877</TD>
<TD><b>52.688</b></TD>
<TD>54.311(1)</TD>
<TD>55.335(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.906)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>19</TD>
<TD>14</TD>
<TD colspan=2>Blake Miles</TD>
<TD colspan=2>2001 Pontiac firebird</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.957</TD>
<TD>55.956(1)</TD>
<TD>53.912</TD>
<TD>54.174</TD>
<TD>54.893(1)</TD>
<TD><b>52.965</b></TD>
<TD>&nbsp;</TD>
<TD><b>52.965</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>57.883(2)</TD>
<TD>53.384</TD>
<TD>53.802</TD>
<TD>55.071(1)</TD>
<TD>68.804</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.277)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>20</TD>
<TD>43</TD>
<TD colspan=2>Shawn McFarland</TD>
<TD colspan=2>2019 Chevrolet Camaro SS</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>58.458</TD>
<TD><s>57.185</s></TD>
<TD>56.792</TD>
<TD>56.652</TD>
<TD><s>59.229</s></TD>
<TD><s>63.740</s></TD>
<TD>&nbsp;</TD>
<TD><b>53.329</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><b>53.329</b></TD>
<TD>58.567(2)</TD>
<TD>53.849</TD>
<TD>57.888(2)</TD>
<TD><s>63.263</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.364)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>21</TD>
<TD>88</TD>
<TD colspan=2>Rod Warner</TD>
<TD colspan=2>2002 camaro ss</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>57.874(1)</TD>
<TD>57.599(1)</TD>
<TD>54.830</TD>
<TD>56.489(1)</TD>
<TD>54.751</TD>
<TD>55.149</TD>
<TD>&nbsp;</TD>
<TD><b>54.048</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>58.700(2)</TD>
<TD><b>54.048</b></TD>
<TD>56.298(1)</TD>
<TD>54.460</TD>
<TD>54.163</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.719)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>22</TD>
<TD>12</TD>
<TD colspan=2>Ted Leonard</TD>
<TD colspan=2>2019 Ford Mustang</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>66.505(1)</TD>
<TD>61.055</TD>
<TD>56.680</TD>
<TD><b>55.541</b></TD>
<TD>56.283</TD>
<TD>56.464</TD>
<TD>&nbsp;</TD>
<TD><b>55.541</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>67.469(1)</TD>
<TD>58.138(1)</TD>
<TD>55.902</TD>
<TD>55.839</TD>
<TD>55.830(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(1.493)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>23</TD>
<TD>190</TD>
<TD colspan=2>1crossedup2010 Wolfe</TD>
<TD colspan=2>2010 Chevrolet Camaro</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>67.505</TD>
<TD>59.287</TD>
<TD>57.984</TD>
<TD>59.374(1)</TD>
<TD>57.847(1)</TD>
<TD>57.383</TD>
<TD>&nbsp;</TD>
<TD><b>55.761</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>57.507</TD>
<TD>56.585</TD>
<TD>58.295(1)</TD>
<TD>56.413</TD>
<TD><b>55.761</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.220)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>24</TD>
<TD>144</TD>
<TD colspan=2>John Kettlewell</TD>
<TD colspan=2>2004 infinity g35</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>60.327</TD>
<TD>58.425</TD>
<TD>58.499</TD>
<TD>58.310</TD>
<TD>58.013</TD>
<TD>65.378(3)</TD>
<TD>&nbsp;</TD>
<TD><b>56.498</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>57.335</TD>
<TD>58.560</TD>
<TD><b>56.498</b></TD>
<TD>57.912(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.737)</TD>
</Table>

