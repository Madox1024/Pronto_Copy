<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>Optima Peak Performance Challenge</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>**** UNOFFICIAL RESULTS (INFORMATIONAL ONLY) ****</b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for GTC [5 Cars] (02:54:24 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>707</b></TD>
<TD colspan=2><b>Dayton de la Houssaye</b></TD>
<TD colspan=4><b>2009 Mazda Mx-5</b></TD>
<TD>24.808</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>13.458</TD>
<TD class='course1'>13.664</TD>
<TD class='course1'>13.356</TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.803</TD>
<TD class='course2'>12.167</TD>
<TD class='course2'>12.050</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>12.958</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>11.850</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 2</b></TD>
<TD><b>704</b></TD>
<TD colspan=2><b>Douglas Wind</b></TD>
<TD colspan=4><b>2004 Dodge SRT4</b></TD>
<TD>25.361</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>13.773</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.590</TD>
<TD class='course2'>12.692</TD>
<TD class='course2'>12.284</TD>
<TD>(0.553)</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>13.645</TD>
<TD class='course1'><b>13.433</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.216</TD>
<TD class='course2'>12.260</TD>
<TD class='course2'><b>11.928</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>13.583</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>11.990</TD>
<TD class='course2'><b>11.928</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 3</b></TD>
<TD><b>335</b></TD>
<TD colspan=2><b>James Garfield</b></TD>
<TD colspan=4><b>2019 Honda Civic Type R</b></TD>
<TD>25.425</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>13.449</TD>
<TD class='course1'>13.437</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.820</TD>
<TD class='course2'>12.247</TD>
<TD class='course2'>12.457</TD>
<TD>(-25.361)</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>13.311</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.416</TD>
<TD class='course2'>12.232</TD>
<TD class='course2'><b>12.114</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 4</b></TD>
<TD><b>428</b></TD>
<TD colspan=2><b>Andrew Scott</b></TD>
<TD colspan=4><b>1993 Ford Probe</b></TD>
<TD>26.941</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>14.182</TD>
<TD class='course1'>14.208</TD>
<TD class='course1'><b>14.056</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.959</TD>
<TD class='course2'><b>12.885</b></TD>
<TD class='course2'>12.968</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 5</b></TD>
<TD><b>79</b></TD>
<TD colspan=2><b>Rich Hughes</b></TD>
<TD colspan=4><b>2000 Mazda Miata</b></TD>
<TD>No Time</TD>
</TR>
</Table>

