<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>Optima Peak Performance Challenge</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>**** UNOFFICIAL RESULTS (INFORMATIONAL ONLY) ****</b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for GTS [9 Cars] (02:39:02 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>36</b></TD>
<TD colspan=2><b>Michael Levitas</b></TD>
<TD colspan=4><b>2014 Porsche 911GT2RSx</b></TD>
<TD>22.441</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>11.768</TD>
<TD class='course1'><b>11.576</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>10.892</TD>
<TD class='course2'><b>10.865</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 2</b></TD>
<TD><b>77</b></TD>
<TD colspan=2><b>Marshall Reinert</b></TD>
<TD colspan=4><b>2000 Chevrolet Corvette</b></TD>
<TD>23.661</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>12.833</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>12.674</TD>
<TD>&nbsp;</TD>
<TD class='course2'>11.698</TD>
<TD class='course2'>11.360</TD>
<TD class='course2'>11.626</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>12.342</b></TD>
<TD class='course1'>13.389</TD>
<TD class='course1'>12.794</TD>
<TD>&nbsp;</TD>
<TD class='course2'>11.361</TD>
<TD class='course2'>11.519</TD>
<TD class='course2'>11.708</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>12.508</TD>
<TD class='course1'>12.596</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>11.395</TD>
<TD class='course2'><b>11.319</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 3</b></TD>
<TD><b>27</b></TD>
<TD colspan=2><b>Richard Forsythe</b></TD>
<TD colspan=4><b>2008 Chevy Corvette</b></TD>
<TD>23.699</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>12.805</TD>
<TD class='course1'><b>12.237</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>13.155</TD>
<TD class='course2'>11.845</TD>
<TD class='course2'>11.835</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>12.426</TD>
<TD class='course1'>12.847</TD>
<TD class='course1'>12.751</TD>
<TD>&nbsp;</TD>
<TD class='course2'>11.550</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>11.627</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>12.425</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>11.462</b></TD>
<TD class='course2'>11.841</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 4</b></TD>
<TD><b>32</b></TD>
<TD colspan=2><b>Todd Mayer</b></TD>
<TD colspan=4><b>2000 Chevrolet Corvette </b></TD>
<TD>24.007</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>12.433</TD>
<TD class='course2'>11.764</TD>
<TD>(-23.699)</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>13.011</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>11.583</b></TD>
<TD class='course2'>12.657</TD>
<TD class='course2'>11.815</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>12.884</TD>
<TD class='course1'><b>12.424</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>11.781</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 5</b></TD>
<TD><b>107</b></TD>
<TD colspan=2><b>Wallace Hattenhauer</b></TD>
<TD colspan=4><b>2006 Dodge SRT10 Viper</b></TD>
<TD>24.257</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>13.360</TD>
<TD class='course1'>13.272</TD>
<TD class='course1'>13.787</TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.799</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>12.352</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>12.792</b></TD>
<TD class='course1'>14.155</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>11.465</b></TD>
<TD class='course2'>12.467</TD>
<TD class='course2'>12.121</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>13.414</TD>
<TD class='course1'>13.161</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.129</TD>
<TD class='course2'>11.783</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 6</b></TD>
<TD><b>82</b></TD>
<TD colspan=2><b>Tim Grant</b></TD>
<TD colspan=4><b>2008 Chevrolet Corvette</b></TD>
<TD>24.776</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>13.157</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>13.166</TD>
<TD>&nbsp;</TD>
<TD class='course2'>12.420</TD>
<TD class='course2'>11.848</TD>
<TD class='course2'>12.163</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>11.619</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 7</b></TD>
<TD><b>122</b></TD>
<TD colspan=2><b>Doug Taft</b></TD>
<TD colspan=4><b>2011 Chevrolet CORVETTE</b></TD>
<TD>26.539</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>15.735</TD>
<TD class='course1'>14.976</TD>
<TD class='course1'>14.501</TD>
<TD>&nbsp;</TD>
<TD class='course2'>13.760</TD>
<TD class='course2'>13.018</TD>
<TD class='course2'>12.702</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>14.201</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>15.220</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>12.408</b></TD>
<TD class='course2'>12.746</TD>
<TD class='course2'>13.320</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>14.600</TD>
<TD class='course1'><b>14.131</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>13.131</TD>
<TD class='course2'>12.497</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 8</b></TD>
<TD><b>66</b></TD>
<TD colspan=2><b>Gunnison Jones</b></TD>
<TD colspan=4><b>2006 Chevrolet Corvette Z06</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b> 9</b></TD>
<TD><b>178</b></TD>
<TD colspan=2><b>Christine Crutcher</b></TD>
<TD colspan=4><b>2019 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
</Table>

