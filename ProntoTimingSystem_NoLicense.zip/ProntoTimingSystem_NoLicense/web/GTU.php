<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>FM3 Drive AutoX Traders World 2021</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class='UNOFFICIAL'> UNOFFICIAL RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for GTU [13 Cars] (03:39:19 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD colspan=2><b>Car</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>Time</b></font></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 1</TD>
<TD>10</TD>
<TD colspan=2>Danny Popp</TD>
<TD colspan=2>2003 Chevrolet Corvette Z06</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>48.677</TD>
<TD>47.993</TD>
<TD>47.712</TD>
<TD>47.418</TD>
<TD><s>46.859</s></TD>
<TD>46.853</TD>
<TD>&nbsp;</TD>
<TD><b>46.242</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>46.655</TD>
<TD>48.208(1)</TD>
<TD>46.845</TD>
<TD>49.044(1)</TD>
<TD><b>46.242</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 2</TD>
<TD>7</TD>
<TD colspan=2>Marshall Reinert</TD>
<TD colspan=2>2000 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>49.685</TD>
<TD>48.299</TD>
<TD>51.569(2)</TD>
<TD>50.119(1)</TD>
<TD>47.543</TD>
<TD>47.686</TD>
<TD>&nbsp;</TD>
<TD><b>46.955</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>47.027</TD>
<TD>47.359</TD>
<TD><b>46.955</b></TD>
<TD>46.963</TD>
<TD>51.257(2)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.713)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 3</TD>
<TD>38</TD>
<TD colspan=2>Bill Hughes</TD>
<TD colspan=2>2003 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.053</TD>
<TD>53.230(2)</TD>
<TD>48.560</TD>
<TD>51.122(1)</TD>
<TD>51.717(2)</TD>
<TD><b>47.918</b></TD>
<TD>&nbsp;</TD>
<TD><b>47.918</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.468</TD>
<TD>49.362(1)</TD>
<TD>51.572(2)</TD>
<TD>49.959(1)</TD>
<TD>48.063</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.963)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 4</TD>
<TD>169</TD>
<TD colspan=2>Bryan Schafer</TD>
<TD colspan=2>2004 Chevrolet Corvette Z06</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.341</TD>
<TD>51.326(1)</TD>
<TD>48.619</TD>
<TD>50.580(1)</TD>
<TD>50.530(1)</TD>
<TD>48.685</TD>
<TD>&nbsp;</TD>
<TD><b>48.240</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.326(1)</TD>
<TD>48.595</TD>
<TD>51.934(2)</TD>
<TD>48.253</TD>
<TD><b>48.240</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.322)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 5</TD>
<TD>111</TD>
<TD colspan=2>David Schroeder</TD>
<TD colspan=2>1997 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.704</TD>
<TD>53.048(1)</TD>
<TD>61.840(3)</TD>
<TD>52.061(1)</TD>
<TD>49.819</TD>
<TD>49.830</TD>
<TD>&nbsp;</TD>
<TD><b>48.436</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>48.820</TD>
<TD>49.056</TD>
<TD>50.309(1)</TD>
<TD>48.946</TD>
<TD><b>48.436</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.196)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 6</TD>
<TD>57</TD>
<TD colspan=2>Joseph Boyer</TD>
<TD colspan=2>1992 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.099</TD>
<TD>51.584</TD>
<TD>52.735(1)</TD>
<TD>49.748</TD>
<TD>49.672</TD>
<TD>49.673</TD>
<TD>&nbsp;</TD>
<TD><b>48.995</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.610(1)</TD>
<TD>51.908(1)</TD>
<TD>50.224</TD>
<TD>50.333</TD>
<TD><b>48.995</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.559)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 7</TD>
<TD>123</TD>
<TD colspan=2>Ray Thomas</TD>
<TD colspan=2>2003 Chevrolet Corvette Z06</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.951</TD>
<TD>51.567</TD>
<TD>50.596</TD>
<TD>50.678</TD>
<TD><s>50.240</s></TD>
<TD>50.176</TD>
<TD>&nbsp;</TD>
<TD><b>49.364</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>49.905</TD>
<TD>52.027(1)</TD>
<TD><b>49.364</b></TD>
<TD>51.094(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.369)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 8</TD>
<TD>363</TD>
<TD colspan=2>Michael Kubiak</TD>
<TD colspan=2>2003 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.450</TD>
<TD>53.993(1)</TD>
<TD>57.982(3)</TD>
<TD>51.707</TD>
<TD>50.693</TD>
<TD>50.485</TD>
<TD>&nbsp;</TD>
<TD><b>49.982</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.410(1)</TD>
<TD><b>49.982</b></TD>
<TD>51.049</TD>
<TD>50.094</TD>
<TD>52.103</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.618)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 9</TD>
<TD>5</TD>
<TD colspan=2>Pat Duncan</TD>
<TD colspan=2>2003 Chevrolet corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><s>56.090</s></TD>
<TD>51.604</TD>
<TD>53.374</TD>
<TD><s>62.405</s></TD>
<TD>50.510</TD>
<TD>50.158</TD>
<TD>&nbsp;</TD>
<TD><b>50.020</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.503(1)</TD>
<TD><b>50.020</b></TD>
<TD>50.654</TD>
<TD>50.216</TD>
<TD>51.698(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.038)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>10</TD>
<TD>20</TD>
<TD colspan=2>Jansen Fischer</TD>
<TD colspan=2>2003 Mitsubishi Evolution 8</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.805</TD>
<TD>52.418</TD>
<TD>50.436</TD>
<TD>50.727</TD>
<TD>52.295(1)</TD>
<TD>50.334</TD>
<TD>&nbsp;</TD>
<TD><b>50.304</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.578(1)</TD>
<TD>55.324(3)</TD>
<TD><b>50.304</b></TD>
<TD>51.827(1)</TD>
<TD>51.634(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.284)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>11</TD>
<TD>22</TD>
<TD colspan=2>Curt Heidel</TD>
<TD colspan=2>2003 Chevrolet Corvette z06</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>56.435</TD>
<TD>53.787</TD>
<TD>51.757</TD>
<TD>51.418</TD>
<TD>51.319</TD>
<TD>51.657</TD>
<TD>&nbsp;</TD>
<TD><b>50.857</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.936</TD>
<TD><b>50.857</b></TD>
<TD>51.195</TD>
<TD>52.997(1)</TD>
<TD>51.273</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.553)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>12</TD>
<TD>30</TD>
<TD colspan=2>Stacy Tucker</TD>
<TD colspan=2>2003 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><s>66.524</s></TD>
<TD><s>59.809</s></TD>
<TD><s>56.639</s></TD>
<TD><s>59.080</s></TD>
<TD>53.382</TD>
<TD>55.401</TD>
<TD>&nbsp;</TD>
<TD><b>53.225</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.594</TD>
<TD><s>54.496</s></TD>
<TD>77.267(1)</TD>
<TD>54.512</TD>
<TD><b>53.225</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(2.368)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>13</TD>
<TD>94</TD>
<TD colspan=2>Michael DiGiorgio</TD>
<TD colspan=2>1994 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>64.918</TD>
<TD>59.919</TD>
<TD>58.507</TD>
<TD>58.010</TD>
<TD>57.653</TD>
<TD>56.963</TD>
<TD>&nbsp;</TD>
<TD><b>55.549</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>56.783</TD>
<TD>57.605(1)</TD>
<TD>56.698</TD>
<TD>56.555</TD>
<TD><b>55.549</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(2.324)</TD>
</Table>

