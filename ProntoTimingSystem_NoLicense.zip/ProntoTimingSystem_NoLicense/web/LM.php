<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>LSFest 3 S Challenge </b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class=''>  RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for LM [94 Cars] (03:14:21 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>40</b></TD>
<TD colspan=2><b>Craig Staley</b></TD>
<TD colspan=4><b>2016 Chevrolet Corvette</b></TD>
<TD>32.209</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.236</TD>
<TD class='course1'>16.488</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.905</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>17.201</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.765</TD>
<TD class='course1'>16.817</TD>
<TD class='course1'>16.689</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>15.962</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>16.553</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.312</TD>
<TD class='course1'><b>16.247</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>16.281</TD>
<TD class='course2'>16.409</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.338</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 2</b></TD>
<TD><b>24</b></TD>
<TD colspan=2><b>Duke Langley</b></TD>
<TD colspan=4><b>2002 Chevrolet Corvette</b></TD>
<TD>32.428</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.542</TD>
<TD class='course1'>16.955</TD>
<TD class='course1'>17.072</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.089</TD>
<TD class='course2'>17.088</TD>
<TD class='course2'>17.216</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.442</TD>
<TD class='course1'>16.686</TD>
<TD class='course1'>17.025</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>16.699</TD>
<TD class='course2'>16.639</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.657</TD>
<TD class='course1'><b>16.322</b></TD>
<TD class='course1'>16.558</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>16.106</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>16.512</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.549</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 3</b></TD>
<TD><b>67</b></TD>
<TD colspan=2><b>Andy Voelkel</b></TD>
<TD colspan=4><b>2020 Chevrolet Corvette</b></TD>
<TD>32.653</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>16.640</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.478</TD>
<TD class='course2'>16.526</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>16.607</TD>
<TD class='course1'>16.510</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.996</TD>
<TD class='course2'>16.610</TD>
<TD class='course2'><b>16.162</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>16.504</TD>
<TD class='course1'>16.788</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.242</TD>
<TD class='course2'>16.411</TD>
<TD class='course2'>16.787</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>16.491</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 4</b></TD>
<TD><b>68</b></TD>
<TD colspan=2><b>Bret Voelkel</b></TD>
<TD colspan=4><b>2020 Chevrolet Corvette</b></TD>
<TD>32.769</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.260</TD>
<TD class='course1'>17.099</TD>
<TD class='course1'>16.697</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>16.622</TD>
<TD class='course2'>16.754</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.667</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.719</TD>
<TD class='course2'>16.566</TD>
<TD class='course2'>16.444</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>16.540</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>16.549</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.411</TD>
<TD class='course2'>16.429</TD>
<TD class='course2'><b>16.229</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.694</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 5</b></TD>
<TD><b>38</b></TD>
<TD colspan=2><b>Scot Spiewak</b></TD>
<TD colspan=4><b>2007 Chevrolet Corvette</b></TD>
<TD>33.643</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.347</TD>
<TD class='course1'>17.345</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.227</TD>
<TD class='course2'>17.222</TD>
<TD class='course2'>17.439</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>16.962</b></TD>
<TD class='course1'>17.141</TD>
<TD class='course1'><b>16.962</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.113</TD>
<TD class='course2'>16.875</TD>
<TD class='course2'><b>16.681</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.197</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>32.883</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 6</b></TD>
<TD><b>12</b></TD>
<TD colspan=2><b>August Falkner</b></TD>
<TD colspan=4><b>2021 Chevrolet Camaro</b></TD>
<TD>33.675</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.710</TD>
<TD class='course1'>17.406</TD>
<TD class='course1'>17.696</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.331</TD>
<TD class='course2'>17.073</TD>
<TD class='course2'>17.325</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.242</TD>
<TD class='course1'><b>16.884</b></TD>
<TD class='course1'>16.918</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.041</TD>
<TD class='course2'>17.026</TD>
<TD class='course2'>17.342</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.518</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>16.791</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 7</b></TD>
<TD><b>2</b></TD>
<TD colspan=2><b>Koda Atwood</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>33.768</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.369</TD>
<TD class='course1'>17.000</TD>
<TD class='course1'>17.379</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.747</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.150</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>16.963</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.340</TD>
<TD class='course2'>17.313</TD>
<TD class='course2'><b>16.805</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 8</b></TD>
<TD><b>1</b></TD>
<TD colspan=2><b>Christopher Andreasen</b></TD>
<TD colspan=4><b>2002 Chevrolet Camaro</b></TD>
<TD>34.449</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.626</TD>
<TD class='course1'>17.619</TD>
<TD class='course1'>17.312</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.094</TD>
<TD class='course2'>17.584</TD>
<TD class='course2'>17.528</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.291</TD>
<TD class='course1'>17.277</TD>
<TD class='course1'><b>17.220</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.229</b></TD>
<TD class='course2'>17.326</TD>
<TD class='course2'>17.529</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 9</b></TD>
<TD><b>138</b></TD>
<TD colspan=2><b>Danny Weller</b></TD>
<TD colspan=4><b>2017 Chevrolet Camaro</b></TD>
<TD>34.562</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.522</TD>
<TD class='course1'>18.569</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>17.938</TD>
<TD class='course2'>17.512</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.819</TD>
<TD class='course1'>17.588</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><b>17.431</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.131</b></TD>
<TD class='course1'>17.584</TD>
<TD class='course1'>17.292</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>17.618</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.433</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>10</b></TD>
<TD><b>25</b></TD>
<TD colspan=2><b>John Maddox</b></TD>
<TD colspan=4><b>2008 Chevrolet Corvette</b></TD>
<TD>34.570</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.955</TD>
<TD class='course1'>17.950</TD>
<TD class='course1'>17.685</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.853</TD>
<TD class='course2'>17.281</TD>
<TD class='course2'><b>17.066</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.504</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>11</b></TD>
<TD><b>6</b></TD>
<TD colspan=2><b>Jordan Cooke</b></TD>
<TD colspan=4><b>2009 Chevrolet Corvette</b></TD>
<TD>34.585</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.333</TD>
<TD class='course1'><b>17.479</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.157</TD>
<TD class='course2'><b>17.106</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>12</b></TD>
<TD><b>54</b></TD>
<TD colspan=2><b>Bryson Parriott</b></TD>
<TD colspan=4><b>2017 Chevrolet Corvette</b></TD>
<TD>34.659</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.536</TD>
<TD class='course1'>18.023</TD>
<TD class='course1'>17.838</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.757</TD>
<TD class='course2'><b>17.379</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.151</TD>
<TD class='course1'>17.531</TD>
<TD class='course1'>17.473</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.031</TD>
<TD class='course2'>17.555</TD>
<TD class='course2'>17.909</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.430</TD>
<TD class='course1'><b>17.280</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>13</b></TD>
<TD><b>10</b></TD>
<TD colspan=2><b>James Darden</b></TD>
<TD colspan=4><b>2017 Chevrolet Camaro</b></TD>
<TD>34.783</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.114</TD>
<TD class='course1'>17.828</TD>
<TD class='course1'>18.102</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.062</TD>
<TD class='course2'>17.496</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.794</TD>
<TD class='course1'>17.764</TD>
<TD class='course1'>17.653</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.502</TD>
<TD class='course2'>17.639</TD>
<TD class='course2'>17.463</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.102</TD>
<TD class='course1'>17.548</TD>
<TD class='course1'><b>17.472</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.353</TD>
<TD class='course2'>17.593</TD>
<TD class='course2'><b>17.311</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>14</b></TD>
<TD><b>61</b></TD>
<TD colspan=2><b>Goosse Mejia (2)</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>34.947</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.634</TD>
<TD class='course1'>18.382</TD>
<TD class='course1'>18.080</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.452</TD>
<TD class='course2'>18.128</TD>
<TD class='course2'>19.200</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.694</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.802</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.064</TD>
<TD class='course2'>18.533</TD>
<TD class='course2'>17.800</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.449</TD>
<TD class='course1'><b>17.522</b></TD>
<TD class='course1'>17.552</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.425</b></TD>
<TD class='course2'>17.598</TD>
<TD class='course2'>17.561</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>15</b></TD>
<TD><b>18</b></TD>
<TD colspan=2><b>Chris Hart</b></TD>
<TD colspan=4><b>2007 Chevrolet Corvette</b></TD>
<TD>34.964</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.781</b></TD>
<TD class='course1'>17.900</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><b>17.183</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.900</TD>
<TD class='course1'>17.846</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.631</TD>
<TD class='course2'>17.636</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>16</b></TD>
<TD><b>53</b></TD>
<TD colspan=2><b>Tony Medina</b></TD>
<TD colspan=4><b>2021 Chevrolet Camaro</b></TD>
<TD>35.003</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.082</TD>
<TD class='course1'>17.981</TD>
<TD class='course1'>18.589</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.528</TD>
<TD class='course2'>18.294</TD>
<TD class='course2'>17.454</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.535</TD>
<TD class='course1'>17.956</TD>
<TD class='course1'>18.092</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.278</b></TD>
<TD class='course2'>17.545</TD>
<TD class='course2'>17.770</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.725</b></TD>
<TD class='course1'>18.360</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.788</TD>
<TD class='course2'>18.025</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>17</b></TD>
<TD><b>9</b></TD>
<TD colspan=2><b>Hector Curiel</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>35.005</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.667</TD>
<TD class='course1'>17.838</TD>
<TD class='course1'>18.186</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.180</TD>
<TD class='course2'>17.922</TD>
<TD class='course2'>17.808</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.774</TD>
<TD class='course1'>17.832</TD>
<TD class='course1'>18.091</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.835</TD>
<TD class='course2'>17.917</TD>
<TD class='course2'>17.673</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.647</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.894</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.578</TD>
<TD class='course2'>18.186</TD>
<TD class='course2'>17.983</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.763</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.358</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>18</b></TD>
<TD><b>147</b></TD>
<TD colspan=2><b>Immanuel Martinez</b></TD>
<TD colspan=4><b>2001 Chevrolet Corvette</b></TD>
<TD>35.253</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.319</TD>
<TD class='course1'>17.826</TD>
<TD class='course1'><b>17.660</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.375</TD>
<TD class='course2'>18.454</TD>
<TD class='course2'><b>17.593</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.822</TD>
<TD class='course1'>17.912</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.011</TD>
<TD class='course2'>18.598</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>19</b></TD>
<TD><b>45</b></TD>
<TD colspan=2><b>Kenneth West</b></TD>
<TD colspan=4><b>2000 Chevrolet Corvette</b></TD>
<TD>35.484</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.193</TD>
<TD class='course1'>18.403</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.276</TD>
<TD class='course2'>18.499</TD>
<TD class='course2'>18.130</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.165</TD>
<TD class='course1'>18.611</TD>
<TD class='course1'><b>18.074</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.588</TD>
<TD class='course2'>17.782</TD>
<TD class='course2'><b>17.410</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>20</b></TD>
<TD><b>3</b></TD>
<TD colspan=2><b>Angela Barnhouse</b></TD>
<TD colspan=4><b>2005 Honda S2000</b></TD>
<TD>35.549</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.093</TD>
<TD class='course1'>18.360</TD>
<TD class='course1'>17.848</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.782</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.786</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>18.173</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.763</b></TD>
<TD class='course2'>18.535</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.556</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>17.936</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.185</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>21</b></TD>
<TD><b>47</b></TD>
<TD colspan=2><b>Gary Youngblood</b></TD>
<TD colspan=4><b>2011 Chevrolet Camaro</b></TD>
<TD>36.229</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.303</TD>
<TD class='course1'>18.626</TD>
<TD class='course1'>19.259</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.260</TD>
<TD class='course2'>18.796</TD>
<TD class='course2'>18.737</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.865</TD>
<TD class='course1'>18.350</TD>
<TD class='course1'>18.411</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.668</TD>
<TD class='course2'><b>18.249</b></TD>
<TD class='course2'>18.285</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.442</TD>
<TD class='course1'>18.440</TD>
<TD class='course1'><b>17.980</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.584</TD>
<TD class='course2'>18.360</TD>
<TD class='course2'>18.486</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.264</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>22</b></TD>
<TD><b>27</b></TD>
<TD colspan=2><b>Mike Morrison</b></TD>
<TD colspan=4><b>2017 Chevrolet Camaro</b></TD>
<TD>36.287</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.139</TD>
<TD class='course1'><b>18.258</b></TD>
<TD class='course1'>18.417</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.029</b></TD>
<TD class='course2'>18.376</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.312</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.386</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>23</b></TD>
<TD><b>26</b></TD>
<TD colspan=2><b>Lester Morrison</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>36.451</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.590</TD>
<TD class='course1'>18.837</TD>
<TD class='course1'>19.306</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.267</TD>
<TD class='course2'>18.317</TD>
<TD class='course2'><b>18.096</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.355</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.214</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>24</b></TD>
<TD><b>55</b></TD>
<TD colspan=2><b>Kenny Pollock</b></TD>
<TD colspan=4><b>2011 Chevrolet Camaro</b></TD>
<TD>36.460</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.273</TD>
<TD class='course1'>18.643</TD>
<TD class='course1'><b>18.276</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.131</TD>
<TD class='course2'>18.828</TD>
<TD class='course2'>18.516</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>18.994</TD>
<TD class='course1'>18.715</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.262</TD>
<TD class='course2'>18.549</TD>
<TD class='course2'><b>18.184</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.859</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.346</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>25</b></TD>
<TD><b>22</b></TD>
<TD colspan=2><b>Gerald Jensen</b></TD>
<TD colspan=4><b>2012 Chevrolet Camaro</b></TD>
<TD>36.750</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>18.335</TD>
<TD class='course1'>18.871</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.860</TD>
<TD class='course2'>19.310</TD>
<TD class='course2'>19.538</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.700</TD>
<TD class='course1'>18.244</TD>
<TD class='course1'>18.701</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>19.035</TD>
<TD class='course2'>18.770</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.212</b></TD>
<TD class='course1'>18.629</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.538</b></TD>
<TD class='course2'>19.389</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>26</b></TD>
<TD><b>57</b></TD>
<TD colspan=2><b>Juan Vasquez</b></TD>
<TD colspan=4><b>2004 Chevrolet Corvette</b></TD>
<TD>36.781</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>18.872</TD>
<TD class='course1'>18.951</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.851</TD>
<TD class='course2'>19.270</TD>
<TD class='course2'>19.011</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.248</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>18.952</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.817</TD>
<TD class='course2'>19.193</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.373</TD>
<TD class='course1'><b>18.264</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.884</TD>
<TD class='course2'><b>18.517</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>27</b></TD>
<TD><b>15</b></TD>
<TD colspan=2><b>Brent Franich</b></TD>
<TD colspan=4><b>2013 Chevrolet Camaro</b></TD>
<TD>36.911</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.443</TD>
<TD class='course1'>19.370</TD>
<TD class='course1'>19.039</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.307</TD>
<TD class='course2'>19.265</TD>
<TD class='course2'>18.711</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.589</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>18.350</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.561</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.921</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>28</b></TD>
<TD><b>8</b></TD>
<TD colspan=2><b>Chad Culver</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>36.920</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.071</TD>
<TD class='course1'>18.535</TD>
<TD class='course1'>19.611</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.736</TD>
<TD class='course2'>19.082</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.115</TD>
<TD class='course1'>18.572</TD>
<TD class='course1'><b>18.460</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.488</TD>
<TD class='course2'>19.218</TD>
<TD class='course2'>19.126</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.468</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.460</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>29</b></TD>
<TD><b>31</b></TD>
<TD colspan=2><b>Valerie Pichette</b></TD>
<TD colspan=4><b>1992 Chevrolet Camaro</b></TD>
<TD>36.945</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.543</TD>
<TD class='course1'>18.630</TD>
<TD class='course1'>18.672</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.035</TD>
<TD class='course2'>18.685</TD>
<TD class='course2'>18.628</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.544</TD>
<TD class='course1'><b>18.541</b></TD>
<TD class='course1'>18.765</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.851</TD>
<TD class='course2'>19.225</TD>
<TD class='course2'><b>18.404</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.833</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.483</TD>
<TD class='course2'>18.813</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>30</b></TD>
<TD><b>43</b></TD>
<TD colspan=2><b>Kyle Thomas</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>36.996</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.053</TD>
<TD class='course1'>19.112</TD>
<TD class='course1'>19.066</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.064</TD>
<TD class='course2'>18.903</TD>
<TD class='course2'>18.692</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.917</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.079</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>31</b></TD>
<TD><b>5</b></TD>
<TD colspan=2><b>Manuel Botelho</b></TD>
<TD colspan=4><b>2015 Chevrolet Corvette</b></TD>
<TD>37.262</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>19.358</TD>
<TD class='course1'>18.968</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.427</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.484</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.796</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.466</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>32</b></TD>
<TD><b>19</b></TD>
<TD colspan=2><b>Cristian Hernandez</b></TD>
<TD colspan=4><b>1996 Nissan 240SX</b></TD>
<TD>37.517</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.141</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.035</TD>
<TD class='course2'>19.925</TD>
<TD class='course2'>19.184</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.043</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>18.550</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.151</TD>
<TD class='course2'><b>18.967</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>33</b></TD>
<TD><b>72</b></TD>
<TD colspan=2><b>david taylor</b></TD>
<TD colspan=4><b>2010 Chevrolet Camaro</b></TD>
<TD>37.863</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.727</TD>
<TD class='course1'>21.148</TD>
<TD class='course1'>20.115</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.253</TD>
<TD class='course2'>19.851</TD>
<TD class='course2'>18.907</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.304</TD>
<TD class='course1'>19.976</TD>
<TD class='course1'>19.469</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>19.961</TD>
<TD class='course2'><b>18.722</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.894</TD>
<TD class='course1'><b>19.141</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.202</TD>
<TD class='course2'>19.818</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>34</b></TD>
<TD><b>52</b></TD>
<TD colspan=2><b>Robert Maya</b></TD>
<TD colspan=4><b>2017 Chevrolet SS</b></TD>
<TD>38.042</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.623</TD>
<TD class='course1'>20.150</TD>
<TD class='course1'>22.345</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.573</TD>
<TD class='course2'>19.825</TD>
<TD class='course2'>19.609</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.482</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>19.025</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.500</TD>
<TD class='course2'>21.400</TD>
<TD class='course2'>20.571</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.323</TD>
<TD class='course1'>19.949</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>19.560</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>35</b></TD>
<TD><b>74</b></TD>
<TD colspan=2><b>Abiel Viruet</b></TD>
<TD colspan=4><b>2001 Pontiac Firebird</b></TD>
<TD>38.055</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.164</TD>
<TD class='course1'>19.366</TD>
<TD class='course1'><b>19.141</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.328</TD>
<TD class='course2'>21.193</TD>
<TD class='course2'><b>18.914</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.507</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.521</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>36</b></TD>
<TD><b>34</b></TD>
<TD colspan=2><b>Adam Rocconi</b></TD>
<TD colspan=4><b>1986 Pontiac Firebird</b></TD>
<TD>38.367</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.906</TD>
<TD class='course1'>19.662</TD>
<TD class='course1'><b>19.211</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.294</TD>
<TD class='course2'>19.832</TD>
<TD class='course2'><b>19.156</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>37</b></TD>
<TD><b>50</b></TD>
<TD colspan=2><b>Kevin Gough</b></TD>
<TD colspan=4><b>2002 Pontiac Firebird</b></TD>
<TD>38.954</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.906</TD>
<TD class='course1'>19.965</TD>
<TD class='course1'><b>19.655</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>21.500</TD>
<TD class='course2'><b>19.299</b></TD>
<TD class='course2'>19.504</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.983</TD>
<TD class='course1'>20.031</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.644</TD>
<TD class='course2'>19.756</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>38</b></TD>
<TD><b>56</b></TD>
<TD colspan=2><b>Shayne Smith</b></TD>
<TD colspan=4><b>1998 Pontiac Firebird</b></TD>
<TD>39.481</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>51.364</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>20.456</TD>
<TD>&nbsp;</TD>
<TD class='course2'>21.234</TD>
<TD class='course2'><b>19.579</b></TD>
<TD class='course2'>20.935</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>19.902</b></TD>
<TD class='course1'>19.970</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>21.394</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>39</b></TD>
<TD><b>141</b></TD>
<TD colspan=2><b>Steve Pope</b></TD>
<TD colspan=4><b>2014 Chevrolet Camaro</b></TD>
<TD>39.716</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.666</TD>
<TD class='course1'>20.417</TD>
<TD class='course1'><b>19.648</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.719</TD>
<TD class='course2'>20.281</TD>
<TD class='course2'><b>20.068</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>40</b></TD>
<TD><b>69</b></TD>
<TD colspan=2><b>Germain Mendoza</b></TD>
<TD colspan=4><b>2009 Pontiac G8</b></TD>
<TD>39.790</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>19.962</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>19.828</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>41</b></TD>
<TD><b>75</b></TD>
<TD colspan=2><b>Cameron Cordrey</b></TD>
<TD colspan=4><b>2010 Chevrolet Camaro</b></TD>
<TD>40.915</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>20.344</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>20.571</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>42</b></TD>
<TD><b>29</b></TD>
<TD colspan=2><b>Victor Palacios</b></TD>
<TD colspan=4><b>2009 Pontiac G8</b></TD>
<TD>40.943</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>20.904</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>20.039</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>43</b></TD>
<TD><b>42</b></TD>
<TD colspan=2><b>Douglas Tait</b></TD>
<TD colspan=4><b>1999 Chevrolet Corvette</b></TD>
<TD>40.995</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.539</TD>
<TD class='course1'><b>20.654</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.775</TD>
<TD class='course2'><b>20.341</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>44</b></TD>
<TD><b>186</b></TD>
<TD colspan=2><b>Dale Hovey</b></TD>
<TD colspan=4><b>2011 Cadillac CTS</b></TD>
<TD>42.371</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>22.276</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>20.095</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>45</b></TD>
<TD><b>44</b></TD>
<TD colspan=2><b>Raymundo Ugalde</b></TD>
<TD colspan=4><b>2005 Pontiac GTO</b></TD>
<TD>43.864</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>24.432</TD>
<TD class='course1'><b>22.006</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>26.083</TD>
<TD class='course2'><b>21.858</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>46</b></TD>
<TD><b>13</b></TD>
<TD colspan=2><b>Dane Ferrari Esias</b></TD>
<TD colspan=4><b>2016 Chevrolet SS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>47</b></TD>
<TD><b>62</b></TD>
<TD colspan=2><b>paul Walker</b></TD>
<TD colspan=4><b>2001 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>48</b></TD>
<TD><b>59</b></TD>
<TD colspan=2><b>Cory Faber</b></TD>
<TD colspan=4><b>1998 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>49</b></TD>
<TD><b>179</b></TD>
<TD colspan=2><b>Mark Gearhart</b></TD>
<TD colspan=4><b>2020 Chevy Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>50</b></TD>
<TD><b>48</b></TD>
<TD colspan=2><b>Jason Froats</b></TD>
<TD colspan=4><b>2016 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>51</b></TD>
<TD><b>16</b></TD>
<TD colspan=2><b>Bryan Garcia-Mitre</b></TD>
<TD colspan=4><b>2010 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>52</b></TD>
<TD><b>14</b></TD>
<TD colspan=2><b>Cameron Fidel</b></TD>
<TD colspan=4><b>2017 Chevrolet SS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>53</b></TD>
<TD><b>66</b></TD>
<TD colspan=2><b>Wes Drelleshak</b></TD>
<TD colspan=4><b>2002 Porsche 911</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>54</b></TD>
<TD><b>60</b></TD>
<TD colspan=2><b>Jeremiah Glover</b></TD>
<TD colspan=4><b>2011 Cadillac CTS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>55</b></TD>
<TD><b>180</b></TD>
<TD colspan=2><b>Chris Sperling</b></TD>
<TD colspan=4><b>2012 Cadillac CTS-V</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>56</b></TD>
<TD><b>65</b></TD>
<TD colspan=2><b>Steve Cudahy</b></TD>
<TD colspan=4><b>2007 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>57</b></TD>
<TD><b>64</b></TD>
<TD colspan=2><b>Laurie Cudahy</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>58</b></TD>
<TD><b>7</b></TD>
<TD colspan=2><b>Jason Corral</b></TD>
<TD colspan=4><b>2010 Cadillac CTS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>59</b></TD>
<TD><b>187</b></TD>
<TD colspan=2><b>Rob Dahn</b></TD>
<TD colspan=4><b>2002  Chevy Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>60</b></TD>
<TD><b>133</b></TD>
<TD colspan=2><b>Pedro Chavez</b></TD>
<TD colspan=4><b>1990 Mazda Miata</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>61</b></TD>
<TD><b>148</b></TD>
<TD colspan=2><b>Ryan Bushnell</b></TD>
<TD colspan=4><b>2015 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>62</b></TD>
<TD><b>73</b></TD>
<TD colspan=2><b>Zachery Burgess</b></TD>
<TD colspan=4><b>2006 Pontiac GTO</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>63</b></TD>
<TD><b>4</b></TD>
<TD colspan=2><b>Glen Barnhouse</b></TD>
<TD colspan=4><b>2000 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>64</b></TD>
<TD><b>177</b></TD>
<TD colspan=2><b>Eric Reyna</b></TD>
<TD colspan=4><b>2013 Chevy Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>65</b></TD>
<TD><b>182</b></TD>
<TD colspan=2><b>Larry Newman</b></TD>
<TD colspan=4><b>2009 Pontiac G6</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>66</b></TD>
<TD><b>152</b></TD>
<TD colspan=2><b>Jeff Schmidt</b></TD>
<TD colspan=4><b>1988 Ford Mustang</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>67</b></TD>
<TD><b>20</b></TD>
<TD colspan=2><b>Greg Zelinski</b></TD>
<TD colspan=4><b>1988 Pontiac Fiero</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>68</b></TD>
<TD><b>131</b></TD>
<TD colspan=2><b>Oscar Ortega</b></TD>
<TD colspan=4><b>2005 Pontiac GTO</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>69</b></TD>
<TD><b>37</b></TD>
<TD colspan=2><b>Demar Smith</b></TD>
<TD colspan=4><b>2005 Pontiac GTO</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>70</b></TD>
<TD><b>36</b></TD>
<TD colspan=2><b>Eric Sheely</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>71</b></TD>
<TD><b>35</b></TD>
<TD colspan=2><b>Richard Schrope</b></TD>
<TD colspan=4><b>2009 Pontiac G8</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>72</b></TD>
<TD><b>149</b></TD>
<TD colspan=2><b>ralph sayre</b></TD>
<TD colspan=4><b>2013 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>73</b></TD>
<TD><b>139</b></TD>
<TD colspan=2><b>Gary Rupert</b></TD>
<TD colspan=4><b>2001 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>74</b></TD>
<TD><b>140</b></TD>
<TD colspan=2><b>Cesar ROBLES-GASTELUM</b></TD>
<TD colspan=4><b>2020 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>75</b></TD>
<TD><b>33</b></TD>
<TD colspan=2><b>Claudia Robles</b></TD>
<TD colspan=4><b>2011 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>76</b></TD>
<TD><b>71</b></TD>
<TD colspan=2><b>Richard Raymond</b></TD>
<TD colspan=4><b>2002 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>77</b></TD>
<TD><b>32</b></TD>
<TD colspan=2><b>Sergio Ramirez</b></TD>
<TD colspan=4><b>2019 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>78</b></TD>
<TD><b>144</b></TD>
<TD colspan=2><b>Shawn Prince</b></TD>
<TD colspan=4><b>2005 Mazda Miata</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>79</b></TD>
<TD><b>145</b></TD>
<TD colspan=2><b>Scott Poncher</b></TD>
<TD colspan=4><b>2010 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>80</b></TD>
<TD><b>21</b></TD>
<TD colspan=2><b>Davion Jackson</b></TD>
<TD colspan=4><b>2017 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>81</b></TD>
<TD><b>41</b></TD>
<TD colspan=2><b>Douglas Tait Jr</b></TD>
<TD colspan=4><b>2001 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>82</b></TD>
<TD><b>49</b></TD>
<TD colspan=2><b>Luis Gonzalez</b></TD>
<TD colspan=4><b>2016 Chevrolet SS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>83</b></TD>
<TD><b>28</b></TD>
<TD colspan=2><b>Chris Nordhaus</b></TD>
<TD colspan=4><b>2013 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>84</b></TD>
<TD><b>181</b></TD>
<TD colspan=2><b>Jeff Naeyaert</b></TD>
<TD colspan=4><b>2016 Chevy Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>85</b></TD>
<TD><b>70</b></TD>
<TD colspan=2><b>frankie adams</b></TD>
<TD colspan=4><b>2016 Chevrolet SS</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>86</b></TD>
<TD><b>143</b></TD>
<TD colspan=2><b>Jose Virelas</b></TD>
<TD colspan=4><b>2005 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>87</b></TD>
<TD><b>23</b></TD>
<TD colspan=2><b>Stephen Komlos</b></TD>
<TD colspan=4><b>2018 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>88</b></TD>
<TD><b>126</b></TD>
<TD colspan=2><b>Brandon Knight</b></TD>
<TD colspan=4><b>2008 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>89</b></TD>
<TD><b>142</b></TD>
<TD colspan=2><b>Aarron Jones</b></TD>
<TD colspan=4><b>2017 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>90</b></TD>
<TD><b>135</b></TD>
<TD colspan=2><b>Rick Sperling</b></TD>
<TD colspan=4><b>2015 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>91</b></TD>
<TD><b>150</b></TD>
<TD colspan=2><b>Joshua Johnson</b></TD>
<TD colspan=4><b>1997 BMW 318ti</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>92</b></TD>
<TD><b>184</b></TD>
<TD colspan=2><b>Emelia Hartford</b></TD>
<TD colspan=4><b>2020 Chevy Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>93</b></TD>
<TD><b>17</b></TD>
<TD colspan=2><b>David Grajeda</b></TD>
<TD colspan=4><b>2006 Pontiac GTO</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>94</b></TD>
<TD><b>30</b></TD>
<TD colspan=2><b>Anthony Pelayo</b></TD>
<TD colspan=4><b>2017 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
</Table>

