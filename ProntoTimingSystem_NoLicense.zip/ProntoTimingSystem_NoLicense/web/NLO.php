<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>FM3 Drive AutoX Traders World 2021</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class='UNOFFICIAL'> UNOFFICIAL RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for NLO [7 Cars] (03:44:20 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD colspan=2><b>Car</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>Time</b></font></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 1</TD>
<TD>35</TD>
<TD colspan=2>Randy Adkins</TD>
<TD colspan=2>2016 Ford GT350</TD>
<TD>          </TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.575</TD>
<TD>49.992</TD>
<TD>48.325</TD>
<TD><s>48.196</s></TD>
<TD>48.072</TD>
<TD>47.552</TD>
<TD>&nbsp;</TD>
<TD><b>47.326</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>49.451(1)</TD>
<TD>51.995(2)</TD>
<TD><b>47.326</b></TD>
<TD>47.680</TD>
<TD>48.529</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 2</TD>
<TD>181</TD>
<TD colspan=2>Robert Armstrong</TD>
<TD colspan=2>2007 Chevrolet Corvette Z06</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.459</TD>
<TD>49.175</TD>
<TD>50.491(1)</TD>
<TD>50.205(1)</TD>
<TD>48.265</TD>
<TD>48.265</TD>
<TD>&nbsp;</TD>
<TD><b>47.360</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>47.976</TD>
<TD><b>47.360</b></TD>
<TD>47.885</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.034)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 3</TD>
<TD>69</TD>
<TD colspan=2>Chris Howell</TD>
<TD colspan=2>1997 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.216</TD>
<TD>49.586</TD>
<TD>48.763</TD>
<TD>48.442</TD>
<TD>48.980</TD>
<TD><s>49.587</s></TD>
<TD>&nbsp;</TD>
<TD><b>47.980</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>48.794</TD>
<TD>51.409(2)</TD>
<TD>48.499</TD>
<TD>48.541</TD>
<TD><b>47.980</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.620)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 4</TD>
<TD>29</TD>
<TD colspan=2>Don Blackstone</TD>
<TD colspan=2>2007 Chevrolet Corvette Z06</TD>
<TD>          </TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.737</TD>
<TD>50.040</TD>
<TD>51.043(1)</TD>
<TD>50.420(1)</TD>
<TD>48.724</TD>
<TD>49.132</TD>
<TD>&nbsp;</TD>
<TD><b>48.086</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>49.188</TD>
<TD><b>48.086</b></TD>
<TD>57.006(4)</TD>
<TD>48.194</TD>
<TD>50.291(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.106)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 5</TD>
<TD>11</TD>
<TD colspan=2>Travis Clark</TD>
<TD colspan=2>2007 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.123</TD>
<TD>49.623</TD>
<TD>49.201</TD>
<TD>50.377</TD>
<TD>49.243</TD>
<TD>50.776(1)</TD>
<TD>&nbsp;</TD>
<TD><b>48.430</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>49.015</TD>
<TD><b>48.430</b></TD>
<TD>49.003</TD>
<TD>62.320(4)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.344)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 6</TD>
<TD>605</TD>
<TD colspan=2>Cody Vencill</TD>
<TD colspan=2>2002 Chevrolet Corvette</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.087</TD>
<TD>53.170(1)</TD>
<TD>53.024(1)</TD>
<TD>52.821(1)</TD>
<TD>52.181(1)</TD>
<TD>50.485</TD>
<TD>&nbsp;</TD>
<TD><b>48.876</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.426(1)</TD>
<TD>54.649</TD>
<TD>50.231</TD>
<TD>51.244(1)</TD>
<TD><b>48.876</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.446)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 7</TD>
<TD>34</TD>
<TD colspan=2>Kenneth Holthouser</TD>
<TD colspan=2>2001 Chevrolet Corvette</TD>
<TD>          </TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.417</TD>
<TD>51.990</TD>
<TD>50.414</TD>
<TD>53.539</TD>
<TD>53.263(1)</TD>
<TD>51.611</TD>
<TD>&nbsp;</TD>
<TD><b>49.856</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.147</TD>
<TD><b>49.856</b></TD>
<TD>52.351(1)</TD>
<TD>51.393(1)</TD>
<TD>52.104(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.980)</TD>
</Table>

