<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>Optima Peak Performance Challenge </b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>**** UNOFFICIAL RESULTS (INFORMATIONAL ONLY) ****</b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for OUTLAW [1 Cars] (03:06:03 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>120</b></TD>
<TD colspan=2><b>Duke Langley</b></TD>
<TD colspan=4><b>2002 Chevrolet Corvette</b></TD>
<TD>27.180</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>14.363</TD>
<TD class='course1'><b>13.496</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>13.684</b></TD>
<TD class='course2'>14.120</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
</Table>

