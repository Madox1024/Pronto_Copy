<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>FM3 Drive AutoX Traders World 2021</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class='UNOFFICIAL'> UNOFFICIAL RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for SCB [8 Cars] (03:40:59 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD colspan=2><b>Car</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>Time</b></font></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 1</TD>
<TD>771</TD>
<TD colspan=2>Bob Beck</TD>
<TD colspan=2>21 Honda Civic Type R</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.083</TD>
<TD><s>35.429</s></TD>
<TD>53.223</TD>
<TD>52.801</TD>
<TD>55.033(1)</TD>
<TD>55.867(2)</TD>
<TD>&nbsp;</TD>
<TD><b>50.062</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.032</TD>
<TD>56.360(3)</TD>
<TD><b>50.062</b></TD>
<TD>62.399(4)</TD>
<TD>50.542</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 2</TD>
<TD>66</TD>
<TD colspan=2>Russ Charlton</TD>
<TD colspan=2>1999 Miata Mazda</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.026</TD>
<TD>52.977(1)</TD>
<TD>51.749</TD>
<TD>50.607</TD>
<TD>53.118(1)</TD>
<TD>50.653</TD>
<TD>&nbsp;</TD>
<TD><b>50.554</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.599(1)</TD>
<TD>76.848</TD>
<TD>50.805</TD>
<TD>51.552</TD>
<TD><b>50.554</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.492)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 3</TD>
<TD>867</TD>
<TD colspan=2>Shawn Struckhoff</TD>
<TD colspan=2>2015 VW GTI</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><s>54.207</s></TD>
<TD>54.949</TD>
<TD>53.266</TD>
<TD>53.298</TD>
<TD>53.232</TD>
<TD>52.464</TD>
<TD>&nbsp;</TD>
<TD><b>50.959</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>51.748</TD>
<TD>51.563</TD>
<TD>51.576</TD>
<TD>54.140(1)</TD>
<TD><b>50.959</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.405)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 4</TD>
<TD>64</TD>
<TD colspan=2>Katie Truesdell</TD>
<TD colspan=2>2017 VW GTI</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.608</TD>
<TD>54.466</TD>
<TD>54.331</TD>
<TD>54.207</TD>
<TD>56.079(1)</TD>
<TD>53.837</TD>
<TD>&nbsp;</TD>
<TD><b>53.473</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.957(1)</TD>
<TD>54.205</TD>
<TD>54.022</TD>
<TD>54.388</TD>
<TD><b>53.473</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(2.514)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 5</TD>
<TD>36</TD>
<TD colspan=2>Alex Motz</TD>
<TD colspan=2>2015 BMW M4</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>58.533(1)</TD>
<TD><s>62.260</s></TD>
<TD>54.385</TD>
<TD>55.862</TD>
<TD>56.032(1)</TD>
<TD>54.826</TD>
<TD>&nbsp;</TD>
<TD><b>53.640</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.679</TD>
<TD>53.727</TD>
<TD>54.725</TD>
<TD>54.690</TD>
<TD><b>53.640</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.167)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 6</TD>
<TD>641</TD>
<TD colspan=2>Kody Cochran</TD>
<TD colspan=2>2012 Volkswagen Jetta</TD>
<TD>          </TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>61.581</TD>
<TD>59.500</TD>
<TD>58.494</TD>
<TD>58.170</TD>
<TD><b>57.439</b></TD>
<TD>57.507</TD>
<TD>&nbsp;</TD>
<TD><b>57.439</b></TD>
</TR>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(3.799)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 7</TD>
<TD>3</TD>
<TD colspan=2>Ryan Niemic</TD>
<TD colspan=2>2021 Honda Civic</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><b>No Time</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 8</TD>
<TD>79</TD>
<TD colspan=2>Jeffrey Gordon</TD>
<TD colspan=2>2007 Chevrolet Cobalt SS</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><b>No Time</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp</TD>
</Table>

