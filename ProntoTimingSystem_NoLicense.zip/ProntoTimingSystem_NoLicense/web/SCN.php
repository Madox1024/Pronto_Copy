<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>FM3 Drive AutoX Traders World 2021</b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class='UNOFFICIAL'> UNOFFICIAL RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for SCN [7 Cars] (03:43:09 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD colspan=2><b>Car</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>Time</b></font></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 1</TD>
<TD>1</TD>
<TD colspan=2>Nathan A Roberts</TD>
<TD colspan=2>2006 Mazda Rx8</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.426</TD>
<TD>50.161</TD>
<TD>49.962</TD>
<TD><s>54.400</s></TD>
<TD>49.365</TD>
<TD><b>48.838</b></TD>
<TD>&nbsp;</TD>
<TD><b>48.838</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.396</TD>
<TD>50.732</TD>
<TD>52.950(2)</TD>
<TD>50.608(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 2</TD>
<TD>19</TD>
<TD colspan=2>Justin King</TD>
<TD colspan=2>2001 Mazda Miata</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.376</TD>
<TD>50.616</TD>
<TD>50.613</TD>
<TD>54.036(2)</TD>
<TD>50.120</TD>
<TD>54.209(2)</TD>
<TD>&nbsp;</TD>
<TD><b>49.325</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>50.417</TD>
<TD>50.349</TD>
<TD>49.832</TD>
<TD>49.802</TD>
<TD><b>49.325</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.487)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD> 3</TD>
<TD>67</TD>
<TD colspan=2>Tavis Spencer</TD>
<TD colspan=2>1990 Mazda Miata</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.111</TD>
<TD>51.332</TD>
<TD>50.562</TD>
<TD>50.238</TD>
<TD>52.542(1)</TD>
<TD>51.943(1)</TD>
<TD>&nbsp;</TD>
<TD><b>49.506</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.578(1)</TD>
<TD>50.500</TD>
<TD>50.051</TD>
<TD>49.996</TD>
<TD><b>49.506</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.181)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 4</TD>
<TD>21</TD>
<TD colspan=2>Mark Hamilton</TD>
<TD colspan=2>1999 Mazda Miata</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.221</TD>
<TD>53.719</TD>
<TD>61.462(1)</TD>
<TD>52.694</TD>
<TD>54.837(1)</TD>
<TD>55.127(1)</TD>
<TD>&nbsp;</TD>
<TD><b>52.654</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>52.672</TD>
<TD><b>52.654</b></TD>
<TD>52.969</TD>
<TD>56.276(1)</TD>
<TD><s>51.653</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(3.148)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 5</TD>
<TD>26</TD>
<TD colspan=2>Jack Allphin</TD>
<TD colspan=2>2006 Chevrolet cobalt</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>56.844</TD>
<TD>54.461</TD>
<TD>55.310</TD>
<TD>55.753</TD>
<TD>54.820</TD>
<TD>56.865(1)</TD>
<TD>&nbsp;</TD>
<TD><b>53.413</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.138</TD>
<TD><b>53.413</b></TD>
<TD>53.518</TD>
<TD>53.420</TD>
<TD>56.087</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.759)</TD>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 6</TD>
<TD>8</TD>
<TD colspan=2>Paul Nielander</TD>
<TD colspan=2>2015 Mazda Miata</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>55.171</TD>
<TD>53.552</TD>
<TD>54.191</TD>
<TD>53.560</TD>
<TD>53.552</TD>
<TD><b>53.501</b></TD>
<TD>&nbsp;</TD>
<TD><b>53.501</b></TD>
</TR>
<TR Class='ProntoLightGray' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>53.771</TD>
<TD>53.644</TD>
<TD>55.804(1)</TD>
<TD>54.928(1)</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.088)</TD>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD> 7</TD>
<TD>76</TD>
<TD colspan=2>DAVID BELLANGER</TD>
<TD colspan=2>2004 Ford Focus SVT</TD>
<TD></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD><s>57.993</s></TD>
<TD>55.136</TD>
<TD>55.669</TD>
<TD>54.354</TD>
<TD>56.992(1)</TD>
<TD>55.435</TD>
<TD>&nbsp;</TD>
<TD><b>53.555</b></TD>
</TR>
<TR Class='w3-white' VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>54.524</TD>
<TD>53.900</TD>
<TD>56.542(1)</TD>
<TD><b>53.555</b></TD>
<TD>53.672</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>(0.054)</TD>
</Table>

