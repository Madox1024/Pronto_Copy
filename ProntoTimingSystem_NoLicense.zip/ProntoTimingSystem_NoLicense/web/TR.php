<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>LSFest 3 S Challenge </b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class=''>  RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for TR [30 Cars] (03:05:27 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>77</b></TD>
<TD colspan=2><b>David Carroll</b></TD>
<TD colspan=4><b>1974 GMC C10</b></TD>
<TD>35.458</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.102</TD>
<TD class='course1'>18.499</TD>
<TD class='course1'>18.527</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.963</TD>
<TD class='course2'>18.829</TD>
<TD class='course2'>18.299</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.034</TD>
<TD class='course1'>18.145</TD>
<TD class='course1'>17.950</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.997</TD>
<TD class='course2'>18.052</TD>
<TD class='course2'>18.181</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.769</TD>
<TD class='course1'>17.813</TD>
<TD class='course1'><b>17.760</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.056</TD>
<TD class='course2'>17.746</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.832</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.698</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 2</b></TD>
<TD><b>39</b></TD>
<TD colspan=2><b>Hondo Miller</b></TD>
<TD colspan=4><b>1970 Chevrolet Blazer</b></TD>
<TD>35.991</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.943</TD>
<TD class='course1'>18.514</TD>
<TD class='course1'>18.634</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.608</TD>
<TD class='course2'>18.665</TD>
<TD class='course2'>18.495</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.137</TD>
<TD class='course1'><b>18.088</b></TD>
<TD class='course1'>18.163</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.417</TD>
<TD class='course2'>18.530</TD>
<TD class='course2'>18.193</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.117</TD>
<TD class='course1'>18.436</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.999</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.126</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.347</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.903</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 3</b></TD>
<TD><b>166</b></TD>
<TD colspan=2><b>Josh Wojciechowski</b></TD>
<TD colspan=4><b>1969 Ford F-100</b></TD>
<TD>37.332</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.488</TD>
<TD class='course1'>19.076</TD>
<TD class='course1'>18.843</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.436</TD>
<TD class='course2'>19.291</TD>
<TD class='course2'>19.170</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>18.331</b></TD>
<TD class='course1'>18.693</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>19.001</b></TD>
<TD class='course2'>19.176</TD>
<TD class='course2'>19.331</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.432</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 4</b></TD>
<TD><b>160</b></TD>
<TD colspan=2><b>Byron McMahon</b></TD>
<TD colspan=4><b>2000 Chevrolet Silverado 1500</b></TD>
<TD>37.449</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.524</b></TD>
<TD class='course1'>18.730</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.038</TD>
<TD class='course2'><b>18.925</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 5</b></TD>
<TD><b>58</b></TD>
<TD colspan=2><b>Chris Allen</b></TD>
<TD colspan=4><b>1963 Ford F-100</b></TD>
<TD>38.026</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.351</TD>
<TD class='course1'>19.525</TD>
<TD class='course1'>20.115</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.032</TD>
<TD class='course2'>20.360</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>18.891</b></TD>
<TD class='course1'>19.083</TD>
<TD class='course1'>18.923</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.517</TD>
<TD class='course2'>19.289</TD>
<TD class='course2'>19.535</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.470</TD>
<TD class='course1'>19.086</TD>
<TD class='course1'>19.167</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.800</TD>
<TD class='course2'><b>19.135</b></TD>
<TD class='course2'>19.293</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 6</b></TD>
<TD><b>156</b></TD>
<TD colspan=2><b>Amanda Hitt</b></TD>
<TD colspan=4><b>1961 Ford F-100</b></TD>
<TD>38.403</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.418</TD>
<TD class='course1'><b>19.170</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.711</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>20.581</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.485</TD>
<TD class='course1'>19.746</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.828</TD>
<TD class='course2'>19.311</TD>
<TD class='course2'><b>19.233</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.475</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 7</b></TD>
<TD><b>158</b></TD>
<TD colspan=2><b>Williams Mcdonald</b></TD>
<TD colspan=4><b>2007 Chevrolet Silverado 1500</b></TD>
<TD>38.975</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.784</TD>
<TD class='course1'><b>19.535</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.240</TD>
<TD class='course2'><b>19.440</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 8</b></TD>
<TD><b>170</b></TD>
<TD colspan=2><b>Michael Sephos</b></TD>
<TD colspan=4><b>2000 Chevrolet Silverado 1500</b></TD>
<TD>41.273</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>24.493</TD>
<TD class='course1'>21.185</TD>
<TD class='course1'>20.612</TD>
<TD>&nbsp;</TD>
<TD class='course2'>22.115</TD>
<TD class='course2'><b>21.008</b></TD>
<TD class='course2'>21.099</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>20.265</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>21.567</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 9</b></TD>
<TD><b>167</b></TD>
<TD colspan=2><b>DANIEL ZAMORA</b></TD>
<TD colspan=4><b>1977 Chevrolet C10</b></TD>
<TD>43.971</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>21.604</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>22.367</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>10</b></TD>
<TD><b>172</b></TD>
<TD colspan=2><b>Jerome Evans</b></TD>
<TD colspan=4><b>2012 Cadillac Escalade</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>11</b></TD>
<TD><b>154</b></TD>
<TD colspan=2><b>Michael Cisneros</b></TD>
<TD colspan=4><b>2007 Chevrolet Trailblazer</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>12</b></TD>
<TD><b>168</b></TD>
<TD colspan=2><b>Matt Karr</b></TD>
<TD colspan=4><b>1986 Chevrolet C10</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>13</b></TD>
<TD><b>129</b></TD>
<TD colspan=2><b>Tim Boyle</b></TD>
<TD colspan=4><b>2004 Chevrolet Silverado 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>14</b></TD>
<TD><b>175</b></TD>
<TD colspan=2><b>Ryan Boyle</b></TD>
<TD colspan=4><b>1986 Chevrolet S10</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>15</b></TD>
<TD><b>132</b></TD>
<TD colspan=2><b>Antonio Becerra-luna</b></TD>
<TD colspan=4><b>1985 Chevrolet K5 Blazer</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>16</b></TD>
<TD><b>151</b></TD>
<TD colspan=2><b>Carlos Arjon</b></TD>
<TD colspan=4><b>2009 Chevrolet Silverado 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>17</b></TD>
<TD><b>153</b></TD>
<TD colspan=2><b>Sean Chandler</b></TD>
<TD colspan=4><b>2009 GMC Sierra 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>18</b></TD>
<TD><b>157</b></TD>
<TD colspan=2><b>Joshua Kaylor</b></TD>
<TD colspan=4><b>2006 Dodge Ram 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>19</b></TD>
<TD><b>171</b></TD>
<TD colspan=2><b>Israel Alcala</b></TD>
<TD colspan=4><b>2004 Chevrolet Silverado 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>20</b></TD>
<TD><b>130</b></TD>
<TD colspan=2><b>Michael Luttrellperez</b></TD>
<TD colspan=4><b>1990 Chevrolet C1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>21</b></TD>
<TD><b>159</b></TD>
<TD colspan=2><b>Steve McGaughys</b></TD>
<TD colspan=4><b>1974 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>22</b></TD>
<TD><b>169</b></TD>
<TD colspan=2><b>Stacy Moore</b></TD>
<TD colspan=4><b>1972 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>23</b></TD>
<TD><b>161</b></TD>
<TD colspan=2><b>Eric Pack</b></TD>
<TD colspan=4><b>1969 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>24</b></TD>
<TD><b>162</b></TD>
<TD colspan=2><b>Fabian Padilla</b></TD>
<TD colspan=4><b>1997 Chevrolet K1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>25</b></TD>
<TD><b>163</b></TD>
<TD colspan=2><b>Ulysses Portillo</b></TD>
<TD colspan=4><b>2003 Chevrolet Silverado 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>26</b></TD>
<TD><b>164</b></TD>
<TD colspan=2><b>Martin Ruiz</b></TD>
<TD colspan=4><b>2000 Chevrolet Silverado 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>27</b></TD>
<TD><b>174</b></TD>
<TD colspan=2><b>Jose Sanchez</b></TD>
<TD colspan=4><b>2003 Chevrolet Silverado 1500</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>28</b></TD>
<TD><b>165</b></TD>
<TD colspan=2><b>Pat Sheely</b></TD>
<TD colspan=4><b>1959 Chevrolet Truck</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>29</b></TD>
<TD><b>173</b></TD>
<TD colspan=2><b>Micah Smith</b></TD>
<TD colspan=4><b>1968 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>30</b></TD>
<TD><b>176</b></TD>
<TD colspan=2><b>Yusaf khan</b></TD>
<TD colspan=4><b>1986 Chevrolet C10</b></TD>
<TD>No Time</TD>
</TR>
</Table>

