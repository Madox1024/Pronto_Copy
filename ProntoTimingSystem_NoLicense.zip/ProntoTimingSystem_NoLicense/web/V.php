<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
<title>Pronto Timing System Live Timing</title>
<meta http-equiv='refresh' content='45'>
<style type='text/css'>
.ProntoLightGray {
background-color:#ECECEC;
}
.course1 
{color:#673ab7!important}
.course2 
{color:#2196F3!important}
</style>
<link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'>
<link rel='stylesheet' href='http://ProntoTimingSystem.com/css/rs.css'>
<link href='https://fonts.googleapis.com/css?family=Black+Ops+One' rel='stylesheet' type='text/css'>
</head>
<body>
<Table align='center' style='width:65%' id='tblHeader' class='w3-table w3-centered'>
<TR><TD><b>LSFest 3 S Challenge </b></TD></TR>
<TR><TD><b></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b><div class=''>  RESULTS</div></b></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><img src='http://www.ProntoTimingSystem.com/ProntoLogo.jpg' width='183' height='92'></img></TD></TR><TR><TD><b><A HREF='http://www.ProntoTimingSystem.com'>www.ProntoTimingSystem.com</A></TD></TR>
<TR><TD><b>&nbsp;</b></TD></TR>
<TR><TD><b>Class standings for V [53 Cars] (03:00:04 PM)</b>
</Table>
&nbsp;<br><br>
<Table align='center' style='width:65%' id='tbl01' class='w3-table w3-border w3-bordered w3-centered'>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD><b>T</b></font></TD>
<TD><b>Pos</b></font></TD>
<TD><b>Car #</b></font></TD>
<TD colspan=2><b>Name</b></font></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=2><b>Car</b></TD>
<TD><b>&nbsp;</b></TD>
<TD><b>&nbsp;</b></TD>
</TR>
<TR class='w3-gray' ALIGN='center' VALIGN='middle'>
<TD colspan=2>&nbsp;</TD>
<TD colspan=3 class='course1'><b>LEFT</b></TD>
<TD><b>&nbsp;</b></TD>
<TD colspan=3 class='course2'><b>RIGHT</b></TD>
<TD><b>TOTAL</b></TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 1</b></TD>
<TD><b>122</b></TD>
<TD colspan=2><b>Josh Leisinger</b></TD>
<TD colspan=4><b>1964 Chevrolet Corvette</b></TD>
<TD>31.724</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.892</TD>
<TD class='course1'>16.361</TD>
<TD class='course1'>16.263</TD>
<TD>&nbsp;</TD>
<TD class='course2'>16.373</TD>
<TD class='course2'>16.204</TD>
<TD class='course2'>16.069</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.161</TD>
<TD class='course1'>16.157</TD>
<TD class='course1'>16.214</TD>
<TD>&nbsp;</TD>
<TD class='course2'>15.841</TD>
<TD class='course2'>16.023</TD>
<TD class='course2'>15.824</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>15.951</b></TD>
<TD class='course1'>16.097</TD>
<TD class='course1'>16.022</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>15.773</b></TD>
<TD class='course2'>15.833</TD>
<TD class='course2'>15.977</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>16.338</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>15.861</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 2</b></TD>
<TD><b>96</b></TD>
<TD colspan=2><b>Nick Relampagos</b></TD>
<TD colspan=4><b>1970 Chevrolet Camaro</b></TD>
<TD>34.065</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>18.332</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.708</TD>
<TD class='course2'>18.094</TD>
<TD class='course2'>17.971</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.428</TD>
<TD class='course1'>18.052</TD>
<TD class='course1'>17.585</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.643</TD>
<TD class='course2'>17.468</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.395</TD>
<TD class='course1'>17.651</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.019</b></TD>
<TD class='course2'>17.374</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.046</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.060</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 3</b></TD>
<TD><b>120</b></TD>
<TD colspan=2><b>Roger Burman</b></TD>
<TD colspan=4><b>1964 Chevrolet Corvette</b></TD>
<TD>34.184</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.976</TD>
<TD class='course1'>17.786</TD>
<TD class='course1'>17.846</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.444</TD>
<TD class='course2'>17.243</TD>
<TD class='course2'>17.461</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.421</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>16.763</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 4</b></TD>
<TD><b>100</b></TD>
<TD colspan=2><b>robby unser</b></TD>
<TD colspan=4><b>1970 Chevrolet Camaro</b></TD>
<TD>34.306</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.958</TD>
<TD class='course1'>17.973</TD>
<TD class='course1'>17.737</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.700</TD>
<TD class='course2'>17.709</TD>
<TD class='course2'>17.901</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.823</TD>
<TD class='course1'>17.234</TD>
<TD class='course1'>17.269</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.559</TD>
<TD class='course2'>17.581</TD>
<TD class='course2'>17.361</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.274</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>17.176</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.445</TD>
<TD class='course2'>19.091</TD>
<TD class='course2'><b>17.130</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 5</b></TD>
<TD><b>80</b></TD>
<TD colspan=2><b>Bob Gawlik</b></TD>
<TD colspan=4><b>1991 Chevrolet Corvette</b></TD>
<TD>34.525</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.241</TD>
<TD class='course1'>17.871</TD>
<TD class='course1'><b>17.235</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.402</TD>
<TD class='course2'>18.609</TD>
<TD class='course2'><b>17.290</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.421</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.594</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 6</b></TD>
<TD><b>82</b></TD>
<TD colspan=2><b>Justin Hertel</b></TD>
<TD colspan=4><b>1988 Pontiac Firebird</b></TD>
<TD>35.152</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.565</TD>
<TD class='course1'>17.539</TD>
<TD class='course1'>18.590</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.898</TD>
<TD class='course2'><b>17.825</b></TD>
<TD class='course2'>18.026</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>17.327</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.809</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.232</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.709</TD>
<TD class='course1'>18.666</TD>
<TD class='course1'>17.545</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.118</TD>
<TD class='course2'>18.853</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 7</b></TD>
<TD><b>99</b></TD>
<TD colspan=2><b>frankie trutanic</b></TD>
<TD colspan=4><b>1986 Buick Regal</b></TD>
<TD>35.284</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.977</TD>
<TD class='course1'>18.348</TD>
<TD class='course1'>18.053</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.325</TD>
<TD class='course2'>18.105</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.311</TD>
<TD class='course1'>18.104</TD>
<TD class='course1'><b>17.951</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.818</TD>
<TD class='course2'>17.439</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.124</TD>
<TD class='course1'>18.349</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>17.643</TD>
<TD class='course2'><b>17.333</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 8</b></TD>
<TD><b>93</b></TD>
<TD colspan=2><b>Kyle Phillips</b></TD>
<TD colspan=4><b>1956 Chevrolet Bel Air</b></TD>
<TD>35.501</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.250</TD>
<TD class='course1'>18.165</TD>
<TD class='course1'>18.006</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.607</TD>
<TD class='course2'>18.222</TD>
<TD class='course2'>18.328</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.045</TD>
<TD class='course1'>18.061</TD>
<TD class='course1'>18.040</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.548</TD>
<TD class='course2'>18.217</TD>
<TD class='course2'>17.933</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.701</TD>
<TD class='course1'><b>17.657</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.844</b></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b> 9</b></TD>
<TD><b>128</b></TD>
<TD colspan=2><b>Harrison Beach</b></TD>
<TD colspan=4><b>1964 Chevrolet Nova Wagon</b></TD>
<TD>35.572</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.798</TD>
<TD class='course1'>18.466</TD>
<TD class='course1'>18.406</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.701</TD>
<TD class='course2'>18.835</TD>
<TD class='course2'>18.080</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.272</TD>
<TD class='course1'><b>17.728</b></TD>
<TD class='course1'>17.755</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.253</TD>
<TD class='course2'>18.080</TD>
<TD class='course2'>17.985</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.462</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'>17.750</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><b>17.844</b></TD>
<TD class='course2'>18.079</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>10</b></TD>
<TD><b>115</b></TD>
<TD colspan=2><b>Marcus Fry</b></TD>
<TD colspan=4><b>1970 Datsun Sedan</b></TD>
<TD>35.579</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.880</TD>
<TD class='course1'>20.788</TD>
<TD class='course1'><b>17.844</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>17.980</TD>
<TD class='course2'>18.233</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>17.949</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>17.735</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>11</b></TD>
<TD><b>85</b></TD>
<TD colspan=2><b>Richard Lammi</b></TD>
<TD colspan=4><b>1977 Datsun 280z</b></TD>
<TD>35.762</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.067</TD>
<TD class='course1'>18.417</TD>
<TD class='course1'>18.311</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.179</TD>
<TD class='course2'><b>17.858</b></TD>
<TD class='course2'>17.936</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>17.904</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.328</TD>
<TD class='course2'>18.258</TD>
<TD class='course2'>18.106</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>12</b></TD>
<TD><b>83</b></TD>
<TD colspan=2><b>Michael Hitt</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>35.832</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.360</TD>
<TD class='course1'>18.842</TD>
<TD class='course1'>18.946</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.811</TD>
<TD class='course2'>18.231</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.425</TD>
<TD class='course1'><b>18.093</b></TD>
<TD class='course1'>18.098</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.162</TD>
<TD class='course2'>18.106</TD>
<TD class='course2'><b>17.739</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>13</b></TD>
<TD><b>108</b></TD>
<TD colspan=2><b>Chris Stoner</b></TD>
<TD colspan=4><b>1988 Pontiac Firebird</b></TD>
<TD>36.349</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.527</TD>
<TD class='course1'>19.314</TD>
<TD class='course1'>19.133</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.637</TD>
<TD class='course2'>19.996</TD>
<TD class='course2'>18.962</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.218</TD>
<TD class='course1'>18.678</TD>
<TD class='course1'>18.552</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.618</TD>
<TD class='course2'><b>18.202</b></TD>
<TD class='course2'>18.398</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>18.803</TD>
<TD class='course1'><b>18.147</b></TD>
<TD class='course1'>18.301</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.491</TD>
<TD class='course2'>18.226</TD>
<TD class='course2'>18.263</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>T</TD>
<TD><b>14</b></TD>
<TD><b>94</b></TD>
<TD colspan=2><b>garrett randall</b></TD>
<TD colspan=4><b>1970 Chevrolet Corvette</b></TD>
<TD>36.470</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.047</TD>
<TD class='course1'><b>18.691</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><b>17.779</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>15</b></TD>
<TD><b>84</b></TD>
<TD colspan=2><b>Charles Huffhines</b></TD>
<TD colspan=4><b>1972 Chevrolet Nova</b></TD>
<TD>36.685</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.254</TD>
<TD class='course1'>18.702</TD>
<TD class='course1'><b>18.362</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.734</TD>
<TD class='course2'><b>18.323</b></TD>
<TD class='course2'>18.404</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.724</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>16</b></TD>
<TD><b>183</b></TD>
<TD colspan=2><b>Scott Timmons</b></TD>
<TD colspan=4><b>1967 Chevy Camaro</b></TD>
<TD>36.898</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.303</TD>
<TD class='course1'>18.636</TD>
<TD class='course1'>22.497</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>18.944</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>17.995</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><b>18.903</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>17</b></TD>
<TD><b>86</b></TD>
<TD colspan=2><b>Bret Madsen</b></TD>
<TD colspan=4><b>1968 Chevrolet Camaro</b></TD>
<TD>37.322</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.903</TD>
<TD class='course1'>18.950</TD>
<TD class='course1'><b>18.596</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.433</TD>
<TD class='course2'>19.221</TD>
<TD class='course2'><b>18.726</b></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.048</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>18</b></TD>
<TD><b>88</b></TD>
<TD colspan=2><b>Justin Morice</b></TD>
<TD colspan=4><b>1969 Chevrolet Camaro</b></TD>
<TD>37.615</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.485</TD>
<TD class='course1'><s>00.000</s></TD>
<TD class='course1'><b>19.091</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.875</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>21.484</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>18.546</TD>
<TD class='course2'><b>18.524</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>19</b></TD>
<TD><b>121</b></TD>
<TD colspan=2><b>Joshua Kellar</b></TD>
<TD colspan=4><b>1967 Chevrolet Camaro</b></TD>
<TD>37.756</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.456</TD>
<TD class='course1'>20.686</TD>
<TD class='course1'>19.735</TD>
<TD>&nbsp;</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'>20.321</TD>
<TD class='course2'>20.408</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>19.193</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.563</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>20</b></TD>
<TD><b>119</b></TD>
<TD colspan=2><b>Kimbal Mackinnon</b></TD>
<TD colspan=4><b>1969 Chevrolet Chevelle</b></TD>
<TD>37.898</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>19.964</TD>
<TD class='course1'>21.616</TD>
<TD class='course1'>19.323</TD>
<TD>&nbsp;</TD>
<TD class='course2'>19.267</TD>
<TD class='course2'>19.339</TD>
<TD class='course2'>19.556</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>19.043</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>18.855</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>21</b></TD>
<TD><b>118</b></TD>
<TD colspan=2><b>Anthony Huntimer</b></TD>
<TD colspan=4><b>1967 Chevrolet Camaro</b></TD>
<TD>38.662</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.628</TD>
<TD class='course1'><b>19.321</b></TD>
<TD class='course1'>52.113</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.427</TD>
<TD class='course2'><b>19.341</b></TD>
<TD class='course2'>20.071</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.788</TD>
<TD class='course1'>20.188</TD>
<TD class='course1'>20.618</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.336</TD>
<TD class='course2'>20.144</TD>
<TD class='course2'>19.406</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>22</b></TD>
<TD><b>95</b></TD>
<TD colspan=2><b>Tyler Randall</b></TD>
<TD colspan=4><b>1966 Buick Skylark</b></TD>
<TD>40.046</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>20.111</b></TD>
<TD class='course1'><s>00.000</s></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.045</TD>
<TD class='course2'><b>19.935</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>23</b></TD>
<TD><b>81</b></TD>
<TD colspan=2><b>Steven Guevara</b></TD>
<TD colspan=4><b>1990 Nissan 240SX</b></TD>
<TD>40.255</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>20.888</TD>
<TD class='course1'><b>19.952</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.678</TD>
<TD class='course2'><b>20.303</b></TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>24</b></TD>
<TD><b>76</b></TD>
<TD colspan=2><b>Devine Badgett</b></TD>
<TD colspan=4><b>1988 Pontiac Fireebird</b></TD>
<TD>40.499</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.875</TD>
<TD class='course1'>20.823</TD>
<TD class='course1'><b>20.604</b></TD>
<TD>&nbsp;</TD>
<TD class='course2'>20.232</TD>
<TD class='course2'><b>19.895</b></TD>
<TD class='course2'>20.987</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>25</b></TD>
<TD><b>109</b></TD>
<TD colspan=2><b>Brad Thompson</b></TD>
<TD colspan=4><b>1987 Chevrolet Caprice</b></TD>
<TD>40.821</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>23.465</TD>
<TD class='course1'>22.137</TD>
<TD class='course1'>21.639</TD>
<TD>&nbsp;</TD>
<TD class='course2'>22.349</TD>
<TD class='course2'><s>00.000</s></TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'><b>19.231</b></TD>
<TD class='course1'>22.002</TD>
<TD class='course1'>21.642</TD>
<TD>&nbsp;</TD>
<TD class='course2'><b>21.590</b></TD>
<TD class='course2'>21.735</TD>
<TD class='course2'><s>00.000</s></TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD class='course1'>21.898</TD>
<TD class='course1'>21.996</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
<TD>&nbsp;</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>26</b></TD>
<TD><b>105</b></TD>
<TD colspan=2><b>John Farnham</b></TD>
<TD colspan=4><b>1980 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>27</b></TD>
<TD><b>134</b></TD>
<TD colspan=2><b>Jesus Gamboa</b></TD>
<TD colspan=4><b>1971 Chevrolet C10 Pickup</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>28</b></TD>
<TD><b>117</b></TD>
<TD colspan=2><b>Thomas Engel</b></TD>
<TD colspan=4><b>1937 Studebaker Dictator</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>29</b></TD>
<TD><b>92</b></TD>
<TD colspan=2><b>William Peterson</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>30</b></TD>
<TD><b>79</b></TD>
<TD colspan=2><b>Peter Chitakian</b></TD>
<TD colspan=4><b>1972 Oldsmobile Cutlass</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>31</b></TD>
<TD><b>78</b></TD>
<TD colspan=2><b>Jason Cavin</b></TD>
<TD colspan=4><b>1969 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>32</b></TD>
<TD><b>116</b></TD>
<TD colspan=2><b>Tom Kamman</b></TD>
<TD colspan=4><b>1987 Chevrolet Corvette</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>33</b></TD>
<TD><b>124</b></TD>
<TD colspan=2><b>Riley Stair</b></TD>
<TD colspan=4><b>1970 Pontiac Firebird</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>34</b></TD>
<TD><b>104</b></TD>
<TD colspan=2><b>Seifullah Zareef</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>35</b></TD>
<TD><b>125</b></TD>
<TD colspan=2><b>Shant Yazijian</b></TD>
<TD colspan=4><b>1962 Volvo Amazon</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>36</b></TD>
<TD><b>103</b></TD>
<TD colspan=2><b>Laura Wright</b></TD>
<TD colspan=4><b>1973 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>37</b></TD>
<TD><b>111</b></TD>
<TD colspan=2><b>Zachary Weidenbach</b></TD>
<TD colspan=4><b>1962 Ford Falcon</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>38</b></TD>
<TD><b>102</b></TD>
<TD colspan=2><b>Tom Walsh</b></TD>
<TD colspan=4><b>1967 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>39</b></TD>
<TD><b>112</b></TD>
<TD colspan=2><b>Mark Wagner</b></TD>
<TD colspan=4><b>1981 Buick Estate Wagon</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>40</b></TD>
<TD><b>101</b></TD>
<TD colspan=2><b>Nick Vazquez</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>41</b></TD>
<TD><b>110</b></TD>
<TD colspan=2><b>christian Van Schyndel</b></TD>
<TD colspan=4><b>1946 Jeep Willys</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>42</b></TD>
<TD><b>90</b></TD>
<TD colspan=2><b>Jon Nidermayer</b></TD>
<TD colspan=4><b>1968 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>43</b></TD>
<TD><b>123</b></TD>
<TD colspan=2><b>Kyle Swanson</b></TD>
<TD colspan=4><b>1966 Chevrolet El Camino</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>44</b></TD>
<TD><b>106</b></TD>
<TD colspan=2><b>Alan Miller</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>45</b></TD>
<TD><b>107</b></TD>
<TD colspan=2><b>Tyler Smith</b></TD>
<TD colspan=4><b>1986 Ford Mustang</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>46</b></TD>
<TD><b>97</b></TD>
<TD colspan=2><b>Alfredo Ruiz</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>47</b></TD>
<TD><b>113</b></TD>
<TD colspan=2><b>George Reiss</b></TD>
<TD colspan=4><b>1970 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>48</b></TD>
<TD><b>185</b></TD>
<TD colspan=2><b>Matt Henry</b></TD>
<TD colspan=4><b>1967 Ford Mustang</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>49</b></TD>
<TD><b>91</b></TD>
<TD colspan=2><b>Roland Nocon</b></TD>
<TD colspan=4><b>1967 Chevrolet Camaro</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>50</b></TD>
<TD><b>89</b></TD>
<TD colspan=2><b>Roberto Navarrete</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>51</b></TD>
<TD><b>114</b></TD>
<TD colspan=2><b>Bradley Mulhern</b></TD>
<TD colspan=4><b>1930 Ford Model A</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-light-gray" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>52</b></TD>
<TD><b>87</b></TD>
<TD colspan=2><b>Az Moosayar</b></TD>
<TD colspan=4><b>1970 Chevrolet Chevelle</b></TD>
<TD>No Time</TD>
</TR>
<TR class="w3-white" VALIGN="center" ALIGN="center">
<TD>&nbsp;</TD>
<TD><b>53</b></TD>
<TD><b>98</b></TD>
<TD colspan=2><b>Sean Thomas</b></TD>
<TD colspan=4><b>1970 Porsche 914</b></TD>
<TD>No Time</TD>
</TR>
</Table>

